# WP Structured Draft Importer

通过结构化 JSON 一键导入 WordPress 草稿的轻量高效插件。

配合大语言模型（通义千问、ChatGPT、Claude、豆包等），将 AI 生成的文章内容快速、安全、无损地导入到 WordPress 中。

---

## 核心特性

- **结构化一键导入**：支持文章标题、富文本正文（纯 HTML）、固定链接 Slug、安全分类分配、标签（Tags）、摘要（Excerpt）。
- **SEO 深度集成**：完整支持 Yoast SEO 核心三字段（焦点关键词 `focus_keyword`、SEO 标题 `seo_title`、元描述 `meta_description`）。
- **智能容错与修复**：
  - 自动剥离 Markdown 代码块包装（```json ... ```）。
  - 智能转义控制字符（换行、回车、制表符）。
  - 智能前瞻启发式识别并转义 HTML 属性内的未转义双引号（例如 `<a href="...">`）。
  - 正文缺失 HTML 标签时的自动段落/标题识别与兜底修补（`auto_htmlify`）。
- **严格分类安全机制**：**绝不自动创建未知分类**。仅匹配当前站点已有的分类名称或 ID，若不存在则跳过并友好警告，保持站点分类体系整洁规范。
- **内置反 AI 味提示词**：内置经过优化的 System Prompt 与通用提示词模板，规范文章结构，打破固定三段式，提高 Google 收录友好度。

---

## 快速安装与使用

1. 将本插件文件夹上传至 WordPress 的 `/wp-content/plugins/wp-structured-draft-importer/` 目录。
2. 在 WordPress 管理后台「插件」菜单中激活 **WP Structured Draft Importer**。
3. 点击左侧菜单「**草稿导入器**」进入控制台。
4. 在「AI 提示词」选项卡复制提示词，发送给大模型生成 JSON。
5. 将生成的 JSON 粘贴到输入框中，点击「**解析预览**」或直接点击「**创建草稿**」。

---

## JSON 字段 Schema

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :---: | :--- |
| `title` | string | **是** | 文章标题（H1），建议 20-40 汉字，含焦点关键词 |
| `content` | string | **是** | 正文内容。必须为纯 HTML（段落用 `<p>`，小节用 `<h2>`/`<h3>`，列表用 `<ul><li>`，对比用 `<table>`） |
| `content_format` | enum | 否 | `html`（默认）或 `markdown` |
| `slug` | string | 否 | 固定链接 Slug，kebab-case 英文小写，如 `robot-vacuum-guide-2026` |
| `category` | string/int | 否 | 分类名称（如 `智能家居`）或分类 ID。必须是站点已存在的分类，插件不会自动创建新分类 |
| `tags` | string[] | 否 | 标签数组，6-10 个简短中文短语（WP 会自动创建未有的标签） |
| `excerpt` | string | 否 | 文章摘要，80-160 字 |
| `source_text` | string | 否 | 原文（用于改写模式） |
| `yoast_seo` | object | 否 | Yoast SEO 字段（`focus_keyword`, `seo_title`, `meta_description`） |

---

## 测试套件

项目内置针对核心算法的测试用例：

```bash
# 测试分类安全匹配逻辑（确保不新建分类）
node tests/test-category-resolve.mjs

# 测试 HTML 属性双引号前瞻启发式修复算法
node tests/test-html-attr-quotes.mjs
```
