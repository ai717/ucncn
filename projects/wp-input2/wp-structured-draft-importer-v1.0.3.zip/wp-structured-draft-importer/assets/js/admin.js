/**
 * WP Structured Draft Importer - Admin JS
 * 交互：Tab 切换、JSON 校验、解析预览、导入提交、复制提示。
 */

( function ( $ ) {
	'use strict';

	var cfg = window.WPSDI || {};
	var i18n = cfg.i18n || {};
	var fields = i18n.fields || {};

	var $json = $( '#wpsdi-json' );
	var $status = $( '#wpsdi-status' );
	var $preview = $( '#wpsdi-preview' );
	var $previewHint = $( '#wpsdi-preview-hint' );
	var $importBtn = $( '#wpsdi-import-btn' );
	var $previewBtn = $( '#wpsdi-preview-btn' );

	/**
	 * 防抖工具。
	 *
	 * @param {Function} fn 回调。
	 * @param {number} wait 等待毫秒。
	 * @return {Function}
	 */
	function debounce( fn, wait ) {
		var t = null;
		return function () {
			var ctx = this, args = arguments;
			clearTimeout( t );
			t = setTimeout( function () {
				fn.apply( ctx, args );
			}, wait );
		};
	}

	/**
	 * 弹出 Toast 提示。
	 *
	 * @param {string} msg 文本。
	 * @param {string} type 类型 ok | error。
	 */
	function toast( msg, type ) {
		type = type || 'ok';
		var icon = 'ok' === type ? 'dashicons-yes-alt' : 'dashicons-warning';
		var $t = $( '<div class="wpsdi-toast wpsdi-toast--' + type + '"><span class="dashicons ' + icon + '"></span><span>' + escapeHtml( msg ) + '</span></div>' ).appendTo( 'body' );
		setTimeout( function () {
			$t.addClass( 'is-visible' );
		}, 10 );
		setTimeout( function () {
			$t.removeClass( 'is-visible' );
			setTimeout( function () {
				$t.remove();
			}, 250 );
		}, 2400 );
	}

	/**
	 * HTML 转义。
	 *
	 * @param {string} s 文本。
	 * @return {string}
	 */
	function escapeHtml( s ) {
		return String( s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	/**
	 * 实时 JSON 校验（支持自动容错与修复兼容探测）。
	 *
	 * @return {void}
	 */
	function validateLive() {
		var raw = $json.val().trim();
		$status.removeClass( 'is-ok is-error' );

		if ( ! raw ) {
			$status.text( i18n.empty || '' );
			return;
		}

		// 1. 尝试直接解析
		try {
			var obj = JSON.parse( raw );
			if ( typeof obj === 'object' && obj !== null && ! Array.isArray( obj ) ) {
				$status.addClass( 'is-ok' ).html(
					'<span class="dashicons dashicons-yes-alt"></span><span>' + escapeHtml( i18n.valid || 'JSON 语法正确，可预览或导入。' ) + '</span>'
				);
				return;
			}
		} catch ( eOrig ) {}

		// 2. 尝试增强修复后解析（自动剥离 Markdown 代码块与转义）
		try {
			var repaired = repairJson( raw );
			var obj2 = JSON.parse( repaired );
			if ( typeof obj2 === 'object' && obj2 !== null && ! Array.isArray( obj2 ) ) {
				$status.addClass( 'is-ok' ).html(
					'<span class="dashicons dashicons-yes-alt" style="color:#059669"></span><span>已自动兼容 Markdown 代码块与转义格式，可正常预览与一键导入（绝无错误代入草稿）</span>' +
					'<button type="button" class="button button-small wpsdi-inline-clean" style="margin-left:10px;vertical-align:middle">一键净化为标准 JSON</button>'
				);
				$status.find( '.wpsdi-inline-clean' ).off( 'click' ).on( 'click', function ( e ) {
					e.preventDefault();
					$json.val( JSON.stringify( obj2, null, 2 ) ).trigger( 'input' );
					toast( '已净化并格式化为标准 JSON', 'ok' );
				} );
				return;
			}
		} catch ( eRep ) {}

		// 3. 降级容错：正则提取器（即使 JSON 严重被破坏，只要有标题正文也能导入！）
		var fuzzyObj = fuzzyExtract( raw );
		if ( fuzzyObj && fuzzyObj.title && fuzzyObj.content ) {
			var fuzzyMsg = '检测到原始输入存在语法瑕疵，但容错引擎已成功解析出文章数据。您可以直接点击「创建草稿」安全入库（已过滤格式瑕疵），或点击右侧一键修复。';
			$status.addClass( 'is-ok' ).html(
				'<span class="dashicons dashicons-yes-alt" style="color:#d97706"></span><span style="color:#b45309">' + fuzzyMsg + '</span>' +
				'<button type="button" class="button button-small wpsdi-inline-repair" style="margin-left:10px;vertical-align:middle">一键修复并替换</button>'
			);
			$status.find( '.wpsdi-inline-repair' ).off( 'click' ).on( 'click', function ( e ) {
				e.preventDefault();
				$json.val( JSON.stringify( fuzzyObj, null, 2 ) ).trigger( 'input' );
				toast( '已自动修复为标准 JSON', 'ok' );
			} );
			return;
		}

		// 4. 彻底无法识别的数据才报错
		$status.addClass( 'is-error' ).html(
			'<span class="dashicons dashicons-warning"></span><span>JSON 解析失败：未识别到有效的标题（title）与正文（content）对象结构。请检查输入内容。</span>'
		);
	}

	/**
	 * 格式化 JSON（先自动剥离修复，再美化展示）。
	 *
	 * @return {void}
	 */
	function formatJson() {
		var raw = $json.val().trim();
		if ( ! raw ) {
			toast( i18n.empty || '', 'error' );
			return;
		}
		try {
			var repaired = repairJson( raw );
			var obj = JSON.parse( repaired );
			var pretty = JSON.stringify( obj, null, 2 );
			$json.val( pretty );
			validateLive();
			toast( '已格式化', 'ok' );
		} catch ( e ) {
			$status.addClass( 'is-error' ).removeClass( 'is-ok' ).html(
				'<span class="dashicons dashicons-warning"></span><span>' + escapeHtml( i18n.invalidJson || '' ) + ' ' + escapeHtml( e.message ) + '</span>'
			);
			toast( ( i18n.invalidJson || '' ) + ' ' + e.message, 'error' );
		}
	}

	/**
	 * 渲染预览。
	 *
	 * @param {Object} data 解析后的数据。
	 * @return {void}
	 */
	function renderPreview( data ) {
		$preview.empty();

		function field( label, valueHtml, modifier ) {
			return '' +
				'<div class="wpsdi-field">' +
					'<div class="wpsdi-field__label">' + escapeHtml( label ) + '</div>' +
					'<div class="wpsdi-field__value ' + ( modifier || '' ) + '">' + valueHtml + '</div>' +
				'</div>';
		}

		function valOrDash( v ) {
			if ( v === undefined || v === null || v === '' ) {
				return '<span class="wpsdi-field__value--muted">—</span>';
			}
			return escapeHtml( String( v ) );
		}

		// title
		$preview.append( field( fields.title || 'title', valOrDash( data.title ) ) );

		// slug
		$preview.append( field( fields.slug || 'slug', valOrDash( data.slug ) ) );

		// content_format
		var fmt = data.content_format || 'html';
		$preview.append( field( fields.content_format || 'format', '<code>' + escapeHtml( fmt ) + '</code>' ) );

		// category
		$preview.append( field( fields.category || 'category', valOrDash( data.category ) ) );

		// tags
		var tagsHtml;
		if ( data.tags && data.tags.length ) {
			tagsHtml = '<div class="wpsdi-field__tags">' +
				$.map( data.tags, function ( t ) {
					return '<span class="wpsdi-tag">' + escapeHtml( t ) + '</span>';
				} ).join( '' ) +
				'</div>';
		} else {
			tagsHtml = valOrDash( '' );
		}
		$preview.append( field( fields.tags || 'tags', tagsHtml ) );

		// excerpt
		$preview.append( field( fields.excerpt || 'excerpt', valOrDash( data.excerpt ) ) );

		// content preview
		var contentHtml;
		if ( data.content ) {
			contentHtml = '<div class="wpsdi-field__content">' +
				( 'markdown' === fmt ? '<pre style="white-space:pre-wrap;margin:0">' + escapeHtml( data.content ) + '</pre>' : data.content ) +
				'</div>';
		} else {
			contentHtml = valOrDash( '' );
		}
		$preview.append( field( fields.content || 'content', contentHtml ) );

		// yoast
		var yoast = data.yoast_seo || {};
		var yoastHas = yoast.focus_keyword || yoast.seo_title || yoast.meta_description;
		var yoastHtml = '';
		if ( yoastHas ) {
			yoastHtml = '<div class="wpsdi-yoast">' +
				field( fields.focus_keyword || 'focus_keyword', valOrDash( yoast.focus_keyword ) ) +
				field( fields.seo_title || 'seo_title', valOrDash( yoast.seo_title ) ) +
				field( fields.meta_description || 'meta_description', valOrDash( yoast.meta_description ) ) +
				'</div>';
			if ( ! cfg.isYoastActive ) {
				yoastHtml += '<div class="wpsdi-field__value--muted" style="margin-top:6px;font-size:12px">⚠ 未检测到 Yoast SEO 插件，导入时此节会被跳过。</div>';
			}
		} else {
			yoastHtml = valOrDash( '' );
		}
		$preview.append( field( fields.yoast_seo || 'yoast_seo', yoastHtml ) );

		// source_text（原文）
		if ( data.source_text ) {
			var srcHtml = '<div class="wpsdi-field__content">' +
				'<pre style="white-space:pre-wrap;margin:0;max-height:200px;overflow:auto">' + escapeHtml( data.source_text ) + '</pre>' +
				'</div>';
			$preview.append( field( fields.source_text || 'source_text（原文）', srcHtml ) );
		}

		$previewHint.text( '' );
	}

	/**
	 * 调用 AJAX 预览。
	 *
	 * @return {void}
	 */
	function ajaxPreview() {
		var raw = $json.val().trim();
		if ( ! raw ) {
			toast( i18n.empty || '', 'error' );
			return;
		}

		var cleanJson = raw;
		try {
			var repaired = repairJson( raw );
			var testObj = JSON.parse( repaired );
			if ( testObj && typeof testObj === 'object' && ! Array.isArray( testObj ) ) {
				cleanJson = repaired;
			}
		} catch ( e ) {
			var fz = fuzzyExtract( raw );
			if ( fz && fz.title && fz.content ) {
				cleanJson = JSON.stringify( fz );
			}
		}

		$previewBtn.prop( 'disabled', true ).addClass( 'wpsdi-loading' );
		$preview.empty().html(
			'<div class="wpsdi-preview__empty"><span class="dashicons dashicons-update-alt" style="animation:wpsdi-spin 0.8s linear infinite"></span><p>解析中…</p></div>'
		);
		$( '#wpsdi-warnings' ).hide();

		$.post( cfg.ajaxUrl, {
			action: cfg.previewAction,
			nonce: cfg.nonce,
			json: cleanJson
		} ).done( function ( res ) {
			if ( res && res.success ) {
				renderPreview( res.data.data || {} );
				var errors = res.data.errors || [];
				var warnings = res.data.warnings || [];
				if ( warnings.length ) {
					var warnHtml = '<div class="wpsdi-warnings__title"><span class="dashicons dashicons-warning"></span>质量提示（不阻塞导入）</div>' +
						'<ul class="wpsdi-warnings__list">' +
						$.map( warnings, function ( w ) {
							return '<li>' + escapeHtml( w ) + '</li>';
						} ).join( '' ) +
						'</ul>';
					$( '#wpsdi-warnings' ).html( warnHtml ).show();
				}
				if ( errors.length ) {
					$previewHint.html( '<span style="color:#b91c1c">⚠ ' + escapeHtml( errors.join( '; ' ) ) + '</span>' );
				}
			} else {
				var msg = ( res && res.data && res.data.message ) || '解析失败';
				var errs = ( res && res.data && res.data.errors ) || [];
				$preview.empty().html(
					'<div class="wpsdi-preview__empty"><span class="dashicons dashicons-warning" style="color:#ef4444"></span><p>' + escapeHtml( msg + ( errs.length ? '：' + errs.join( '; ' ) : '' ) ) + '</p></div>'
				);
			}
		} ).fail( function () {
			$preview.empty().html(
				'<div class="wpsdi-preview__empty"><span class="dashicons dashicons-warning" style="color:#ef4444"></span><p>网络错误，请重试。</p></div>'
			);
		} ).always( function () {
			$previewBtn.prop( 'disabled', false ).removeClass( 'wpsdi-loading' );
		} );
	}

	/**
	 * 构建隐藏表单并提交导入（带 nonce，具备自动修复净化与非阻断放行能力）。
	 *
	 * @return {void}
	 */
	function submitImport() {
		var raw = $json.val().trim();
		if ( ! raw ) {
			toast( i18n.empty || '', 'error' );
			return;
		}

		// 自动通过增强型 repairJson 与降级 fuzzyExtract 剥离 Markdown 代码块、闲聊文本及控制字符
		var cleanJson = raw;
		try {
			var repaired = repairJson( raw );
			var testObj = JSON.parse( repaired );
			if ( testObj && typeof testObj === 'object' && ! Array.isArray( testObj ) ) {
				cleanJson = repaired;
			}
		} catch ( e ) {
			var fz = fuzzyExtract( raw );
			if ( fz && fz.title && fz.content ) {
				cleanJson = JSON.stringify( fz );
			}
		}

		$importBtn.prop( 'disabled', true ).addClass( 'wpsdi-loading' );

		// admin-post.php URL 拼装。
		var adminPostUrl = cfg.ajaxUrl.replace( /admin-ajax\.php$/, 'admin-post.php' );
		var $form = $( '<form method="post" action="' + adminPostUrl + '" style="display:none"></form>' );

		$form.append( '<input type="hidden" name="action" value="wpsdi_import">' );
		$form.append( '<input type="hidden" name="wpsdi_nonce" value="' + cfg.nonce + '">' );
		var $jsonField = $( '<textarea name="wpsdi_json"></textarea>' ).val( cleanJson );
		$form.append( $jsonField );
		$( 'body' ).append( $form );
		// 同步提交以让浏览器跳转回 flash 提示页。
		$form[ 0 ].submit();
	}

	/**
	 * 复制到剪贴板。
	 *
	 * @param {string} targetId 目标元素 ID。
	 * @param {jQuery} $btn 触发按钮。
	 * @return {void}
	 */
	function copyText( targetId, $btn ) {
		var el = document.getElementById( targetId );
		if ( ! el ) {
			toast( i18n.copyFail || '', 'error' );
			return;
		}
		var text = el.innerText || el.textContent || '';
		var fallback = function () {
			var ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild( ta );
			ta.select();
			try {
				document.execCommand( 'copy' );
				toast( i18n.copyOk || '', 'ok' );
			} catch ( e ) {
				toast( i18n.copyFail || '', 'error' );
			}
			document.body.removeChild( ta );
		};
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( function () {
				toast( i18n.copyOk || '', 'ok' );
			}, function () {
				fallback();
			} );
		} else {
			fallback();
		}
	}

	/**
	 * AI 输出 JSON 增强型修复：
	 * - 清理 UTF-8 BOM 和零宽不可见字符
	 * - 提取 Markdown 代码块（```json ... ```）及剥离前导/后置闲聊文本
	 * - 智能提取最外层 { ... } 核心 JSON 对象
	 * - 非法反斜杠转义自动修复（如文件路径 C:\path 或正则 \d）
	 * - 字符串内未转义的换行符 / 回车 / 制表符
	 * - 字符串内未转义的双引号（特别是 HTML 属性 <a href="..."> 里的裸双引号）
	 * - 对象 / 数组末尾多余的逗号及连续多逗号
	 * - 注释 // 和 /* *\/ 剔除
	 * - 结构层全角标点（中文冒号、逗号）容错
	 *
	 * @param {string} json 原始 JSON。
	 * @return {string} 修复后的 JSON。
	 */
	function repairJson( json ) {
		if ( typeof json !== 'string' ) {
			json = String( json || '' );
		}

		// 1. 清理 UTF-8 BOM 和常见 Unicode 零宽/不可见字符
		json = json.replace( /[\uFEFF\u200B-\u200D\u200E\u200F]/g, '' );

		// 2. 智能提取核心 JSON 区块（剥离 Markdown 代码块包装及前导/后置闲聊文本）
		var blockMatch = json.match( /```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/i );
		if ( blockMatch ) {
			json = blockMatch[ 1 ];
		} else {
			var openMatch = json.match( /```(?:json)?\s*\n?([\s\S]*)$/i );
			if ( openMatch && openMatch[ 1 ].indexOf( '{' ) !== -1 ) {
				json = openMatch[ 1 ];
			}
		}

		// 提取最外层的 { ... }，剥离一切前置和后置闲聊说明或多余反引号
		var firstBrace = json.indexOf( '{' );
		var lastBrace = json.lastIndexOf( '}' );
		if ( firstBrace !== -1 && lastBrace > firstBrace ) {
			json = json.substring( firstBrace, lastBrace + 1 );
		} else if ( firstBrace !== -1 && lastBrace === -1 ) {
			json = json.substring( firstBrace ) + '}';
		}

		// 将 HTML 标签属性里的裸双引号转为单引号（如 <a href="url"> -> <a href='url'>），彻底防止破坏 JSON 字符串
		json = json.replace( /(<(?:a|img|source|iframe|link)\b[^>]*?\s(?:href|src|class|id|target|rel|style)=)"([^"]*)"/gi, "$1'$2'" );
		json = json.replace( /(<(?:a|img|source|iframe|link)\b[^>]*?\s(?:href|src|class|id|target|rel|style)=)"([^"]*)"/gi, "$1'$2'" );

		// 3. 逐字符扫描
		var result = '';
		var inString = false;
		var escaped = false;
		var len = json.length;

		for ( var i = 0; i < len; i++ ) {
			var ch = json.charAt( i );

			if ( inString ) {
				if ( escaped ) {
					result += ch;
					escaped = false;
					continue;
				}

				if ( ch === '\\' ) {
					var next = ( i + 1 < len ) ? json.charAt( i + 1 ) : '';
					if ( next === '"' || next === '\\' || next === '/' || next === 'b' || next === 'f' || next === 'n' || next === 'r' || next === 't' ) {
						result += ch;
						escaped = true;
						continue;
					}
					if ( next === 'u' ) {
						var hex = json.substring( i + 2, i + 6 );
						if ( /^[0-9a-fA-F]{4}$/.test( hex ) ) {
							result += ch;
							escaped = true;
							continue;
						}
					}
					// 非法转义符（如文件路径反斜杠），自动修复为 \\
					result += '\\\\';
					continue;
				}

				if ( ch === '"' ) {
					// 前瞻：跳过空白，判断后面是不是 JSON 结构字符。
					var j = i + 1;
					while ( j < len && /\s/.test( json.charAt( j ) ) ) {
						j++;
					}
					var nextCh = ( j < len ) ? json.charAt( j ) : '';
					// 合法的字符串结束符后面必须是 , } ] : 或 EOF。
					if ( '' === nextCh || ',' === nextCh || '}' === nextCh || ']' === nextCh || ':' === nextCh ) {
						result += ch;
						inString = false;
						continue;
					}
					// 否则视为 HTML 属性内未转义的 "，转义为 \"，继续留在字符串内。
					result += '\\"';
					continue;
				}

				// 字符串内的控制字符 → 转义。
				var code = ch.charCodeAt( 0 );
				if ( ch === '\n' ) {
					result += '\\n';
				} else if ( ch === '\r' ) {
					result += '\\r';
				} else if ( ch === '\t' ) {
					result += '\\t';
				} else if ( code < 0x20 ) {
					result += '\\u' + ( '0000' + code.toString( 16 ) ).slice( -4 );
				} else {
					result += ch;
				}
			} else {
				// 跳过 // 和 /* */ 注释。
				if ( ch === '/' && i + 1 < len ) {
					var nextChar = json.charAt( i + 1 );
					if ( nextChar === '/' ) {
						while ( i < len && json.charAt( i ) !== '\n' ) {
							i++;
						}
						result += '\n';
						continue;
					}
					if ( nextChar === '*' ) {
						i += 2;
						while ( i < len - 1 && !( json.charAt( i ) === '*' && json.charAt( i + 1 ) === '/' ) ) {
							i++;
						}
						i++;
						continue;
					}
				}

				// 结构层：容错中文全角符号
				if ( ch === '：' ) {
					result += ':';
					continue;
				}
				if ( ch === '，' ) {
					result += ',';
					continue;
				}

				if ( ch === '"' ) {
					inString = true;
					result += ch;
					continue;
				}

				result += ch;
			}
		}

		// 移除连续多逗号与末尾多余逗号。
		result = result.replace( /,\s*,+/g, ',' );
		result = result.replace( /,\s*([\]}])/g, '$1' );

		return result;
	}

	/**
	 * 正则降级容错提取器：当 JSON 语法破损时，仍能准确抽取出主要字段并组装为合规对象。
	 *
	 * @param {string} raw 原始文本。
	 * @return {Object|null} 提取出的数据对象，若无法提取到 title 与 content 则返回 null。
	 */
	function fuzzyExtract( raw ) {
		if ( typeof raw !== 'string' || ! raw.trim() ) {
			return null;
		}

		var data = {};

		// 1. title
		var mTitle = raw.match( /"title"\s*:\s*"((?:[^"\\]|\\.)*)"/ );
		if ( mTitle ) {
			data.title = mTitle[ 1 ].replace( /\\"/g, '"' ).replace( /\\n/g, '\n' ).replace( /`/g, '' ).trim();
		} else {
			return null;
		}

		// 2. content
		var mContent = raw.match( /"content"\s*:\s*"([\s\S]*?)"\s*,\s*"(?:content_format|slug|category|tags|excerpt|yoast_seo|source_text)"/ );
		if ( ! mContent ) {
			mContent = raw.match( /"content"\s*:\s*"([\s\S]*?)"\s*\}\s*$/ );
		}
		if ( ! mContent ) {
			var idxContent = raw.indexOf( '"content"' );
			if ( idxContent !== -1 ) {
				var afterContent = raw.substring( idxContent );
				var firstQ = afterContent.indexOf( '":' );
				if ( firstQ !== -1 ) {
					var strStart = afterContent.indexOf( '"', firstQ + 2 );
					if ( strStart !== -1 ) {
						var lastQ = afterContent.lastIndexOf( '"' );
						if ( lastQ > strStart ) {
							mContent = [ '', afterContent.substring( strStart + 1, lastQ ) ];
						}
					}
				}
			}
		}

		if ( mContent && mContent[ 1 ] ) {
			var c = mContent[ 1 ].replace( /\\"/g, '"' ).replace( /\\n/g, '\n' );
			c = c.replace( /^```[a-zA-Z]*\s*/i, '' ).replace( /\s*```$/, '' );
			data.content = c;
		} else {
			return null;
		}

		// 3. content_format
		var mFmt = raw.match( /"content_format"\s*:\s*"(html|markdown)"/i );
		data.content_format = mFmt ? mFmt[ 1 ].toLowerCase() : 'html';

		// 4. slug
		var mSlug = raw.match( /"slug"\s*:\s*"([a-zA-Z0-9\-_]+)"/ );
		if ( mSlug ) {
			data.slug = mSlug[ 1 ];
		}

		// 5. excerpt
		var mExcerpt = raw.match( /"excerpt"\s*:\s*"((?:[^"\\]|\\.)*)"/ );
		if ( mExcerpt ) {
			data.excerpt = mExcerpt[ 1 ].replace( /\\"/g, '"' ).replace( /\\n/g, '\n' );
		}

		// 6. tags
		var mTags = raw.match( /"tags"\s*:\s*\[([\s\S]*?)\]/ );
		if ( mTags ) {
			var tagMatches = mTags[ 1 ].match( /"((?:[^"\\]|\\.)*)"/g );
			if ( tagMatches ) {
				data.tags = $.map( tagMatches, function ( t ) {
					return t.replace( /^"|"$/g, '' ).replace( /\\"/g, '"' ).trim();
				} );
			}
		}

		// 7. yoast_seo
		var mYoast = raw.match( /"yoast_seo"\s*:\s*\{([\s\S]*?)\}/ );
		if ( mYoast ) {
			var yStr = mYoast[ 1 ];
			var yoast = {};
			var mFk = yStr.match( /"focus_keyword"\s*:\s*"((?:[^"\\]|\\.)*)"/ );
			if ( mFk ) yoast.focus_keyword = mFk[ 1 ].replace( /\\"/g, '"' );
			var mSt = yStr.match( /"seo_title"\s*:\s*"((?:[^"\\]|\\.)*)"/ );
			if ( mSt ) yoast.seo_title = mSt[ 1 ].replace( /\\"/g, '"' );
			var mMd = yStr.match( /"meta_description"\s*:\s*"((?:[^"\\]|\\.)*)"/ );
			if ( mMd ) yoast.meta_description = mMd[ 1 ].replace( /\\"/g, '"' );
			if ( Object.keys( yoast ).length > 0 ) {
				data.yoast_seo = yoast;
			}
		}

		return data;
	}

	/**
	 * 一键修复 + 格式化 JSON。
	 *
	 * @return {void}
	 */
	function repairAndFormatJson() {
		var raw = $json.val();
		if ( ! raw.trim() ) {
			toast( i18n.empty || '', 'error' );
			return;
		}

		try {
			var fixed = repairJson( raw );
			var obj = JSON.parse( fixed );
			$json.val( JSON.stringify( obj, null, 2 ) );
			$status.addClass( 'is-ok' ).removeClass( 'is-error' ).html(
				'<span class="dashicons dashicons-yes-alt"></span><span>已自动剥离代码块并修复格式</span>'
			);
			toast( '已自动修复并格式化 JSON', 'ok' );
			validateLive();
			return;
		} catch ( e ) {
			// 降级：尝试正则字段提取器
			var fz = fuzzyExtract( raw );
			if ( fz && fz.title && fz.content ) {
				$json.val( JSON.stringify( fz, null, 2 ) );
				$status.addClass( 'is-ok' ).removeClass( 'is-error' ).html(
					'<span class="dashicons dashicons-yes-alt"></span><span>已通过智能容错引擎成功提取文章并重构为标准 JSON</span>'
				);
				toast( '已自动重构为合规 JSON', 'ok' );
				validateLive();
				return;
			}

			// 修复后仍失败，定位错误。
			var posMatch = /position\s+(\d+)/i.exec( e.message );
			var hint = '错误：' + e.message;
			if ( posMatch ) {
				var pos = parseInt( posMatch[ 1 ], 10 );
				var context = raw.substring( Math.max( 0, pos - 20 ), Math.min( raw.length, pos + 20 ) );
				hint += '。位置附近：' + escapeHtml( context );
			}
			$status.addClass( 'is-error' ).removeClass( 'is-ok' ).html(
				'<span class="dashicons dashicons-warning"></span><span>' + hint + '</span>'
			);
			toast( '修复失败，请检查格式', 'error' );
		}
	}

	/**
	 * Tab 切换。
	 *
	 * @return {void}
	 */
	function initTabs() {
		$( '.wpsdi-tabs__btn' ).on( 'click', function () {
			var $btn = $( this );
			var tab = $btn.data( 'tab' );
			$( '.wpsdi-tabs__btn' ).removeClass( 'is-active' ).attr( 'aria-selected', 'false' );
			$btn.addClass( 'is-active' ).attr( 'aria-selected', 'true' );
			$( '.wpsdi-panel' ).removeClass( 'is-active' );
			$( '.wpsdi-panel[data-panel="' + tab + '"]' ).addClass( 'is-active' );
		} );
	}

	/**
	 * 初始化。
	 *
	 * @return {void}
	 */
	function init() {
		initTabs();

		$json.on( 'input', debounce( validateLive, 200 ) );
		$( '#wpsdi-format' ).on( 'click', formatJson );
		$( '#wpsdi-repair' ).on( 'click', repairAndFormatJson );
		$( '#wpsdi-clear' ).on( 'click', function () {
			$json.val( '' ).trigger( 'input' ).focus();
		} );
		$previewBtn.on( 'click', ajaxPreview );
		$importBtn.on( 'click', submitImport );

		// 原文输入 → 自动写入 JSON 的 source_text 字段。
		var $source = $( '#wpsdi-source' );
		if ( $source.length ) {
			$source.on( 'input', debounce( function () {
				var raw = $json.val().trim();
				var sourceVal = $source.val();
				var obj;
				try {
					obj = JSON.parse( raw );
				} catch ( e ) {
					// JSON 还没准备好，不处理。
					return;
				}
				if ( sourceVal ) {
					obj.source_text = sourceVal;
				} else {
					delete obj.source_text;
				}
				$json.val( JSON.stringify( obj, null, 2 ) ).trigger( 'input' );
			}, 300 ) );
		}

		$( '.wpsdi-copy' ).on( 'click', function () {
			copyText( $( this ).data( 'copy-target' ), $( this ) );
		} );

		// 初次进入立即校验。
		validateLive();
	}

	$( document ).ready( init );
} )( jQuery );
