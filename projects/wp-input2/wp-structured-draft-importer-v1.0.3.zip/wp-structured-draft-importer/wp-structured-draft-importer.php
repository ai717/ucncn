<?php
/**
 * Plugin Name:       WP Structured Draft Importer
 * Plugin URI:        https://example.com/wp-structured-draft-importer
 * Description:       通过结构化 JSON 一键导入 WordPress 草稿：自动填充标题、正文、固定链接、分类、标签、摘要，以及 Yoast SEO 焦点关键词 / SEO 标题 / 元描述。内置 AI 提示词模板，配合千问 / ChatGPT / 豆包快速产出合规数据。
 * Version:           1.0.3
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Your Name
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-structured-draft-importer
 * Domain Path:       /languages
 *
 * @package WpStructuredDraftImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // 禁止直接访问。
}

define( 'WPSDI_VERSION', '1.0.3' );
define( 'WPSDI_PLUGIN_FILE', __FILE__ );
define( 'WPSDI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPSDI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPSDI_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once WPSDI_PLUGIN_DIR . 'includes/class-wpsdi-importer.php';
require_once WPSDI_PLUGIN_DIR . 'includes/class-wpsdi-admin-page.php';

/**
 * 插件入口：注册后台菜单与资源加载。
 *
 * @return WPSDI_Admin_Page
 */
function wpsdi() {
	static $instance = null;
	if ( null === $instance ) {
		$instance = new WPSDI_Admin_Page();
	}
	return $instance;
}

add_action( 'plugins_loaded', 'wpsdi' );

/**
 * 激活钩子：仅检查 PHP 版本。
 *
 * @return void
 */
function wpsdi_activate() {
	if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
		deactivate_plugins( WPSDI_PLUGIN_BASENAME );
		wp_die( esc_html__( '本插件需要 PHP 7.4 或更高版本。', 'wp-structured-draft-importer' ) );
	}
}
register_activation_hook( __FILE__, 'wpsdi_activate' );
