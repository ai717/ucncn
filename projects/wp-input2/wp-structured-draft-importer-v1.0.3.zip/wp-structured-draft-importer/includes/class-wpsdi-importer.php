<?php
/**
 * 导入器：解析结构化 JSON 并创建 WordPress 草稿。
 *
 * @package WpStructuredDraftImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPSDI_Importer
 */
class WPSDI_Importer {

	/**
	 * Schema 版本号。
	 *
	 * @var string
	 */
	const SCHEMA_VERSION = '1.1';

	/**
	 * 解析后的数据。
	 *
	 * @var array|null
	 */
	protected $data = null;

	/**
	 * 错误信息列表（阻塞导入）。
	 *
	 * @var string[]
	 */
	protected $errors = array();

	/**
	 * 警告信息列表（不阻塞导入，仅提示）。
	 *
	 * @var string[]
	 */
	protected $warnings = array();

	/**
	 * 是否已安装 Yoast SEO。
	 *
	 * @return bool
	 */
	public static function is_yoast_active() {
		return defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Meta' ) || in_array(
			'wordpress-seo/wp-seo.php',
			(array) get_option( 'active_plugins', array() ),
			true
		);
	}

	/**
	 * 返回完整 Schema 规范（中文说明）。
	 *
	 * @return array
	 */
	public static function get_schema() {
		return array(
			'version'         => self::SCHEMA_VERSION,
			'description'     => 'WP Structured Draft Importer 结构化数据规范（Google 收录友好）',
			'required'        => array( 'title', 'content' ),
			'fields'          => array(
				'title'          => array(
					'type'        => 'string',
					'required'    => true,
					'max_length'  => 80,
					'description' => '文章标题（H1）。20-40 个汉字，含焦点关键词并靠前；Google 中文 SERP 标题宽度有限，避免过长被截断。',
				),
				'content'        => array(
					'type'        => 'string',
					'required'    => true,
					'description' => '正文内容。★必须为纯 HTML，禁止纯文本！每个段落用 <p>，标题用 <h2>/<h3>，列表用 <ul><li>，对比用 <table>，加粗用 <strong>，引用用 <blockquote>，链接用 <a href=...>。禁止用 \\n 假装分段。≥1200 字。≥3 个 h2，复杂主题用 h3。禁止 Markdown 脚注/引用/链接/表格语法。原文中的 URL 必须以 <a href> 内联出现在正文里。',
				),
				'content_format' => array(
					'type'        => 'enum',
					'enum'        => array( 'html', 'markdown' ),
					'default'     => 'html',
					'description' => '正文格式。必须与 content 内容一致：用 HTML 就写 html，用 Markdown 就写 markdown。推荐 html。',
				),
				'source_text'    => array(
					'type'        => 'string',
					'required'    => false,
					'description' => '原文（可选）。用于改写模式：AI 会基于原文理解、优化、丰富内容，而非从零创作。',
				),
				'slug'           => array(
					'type'        => 'string',
					'required'    => false,
					'max_length'  => 60,
					'description' => '固定链接 slug。全小写英文 + 连字符（kebab-case），2-5 个单词，贴近主题；不含中文/空格/特殊符号。如 "robot-vacuum-guide-2026"。留空则使用标题拼音化。',
				),
				'category'       => array(
					'type'        => 'string|integer',
					'required'    => false,
					'description' => '文章分类。必须是当前 WordPress 站点中**已经存在的分类名称（中文名称字符串）或分类 ID（整数）**。插件不会自动创建新的分类。留空则不分配分类，草稿建立后在后台手动选择即可。',
				),
				'tags'           => array(
					'type'        => 'string[]',
					'required'    => false,
					'max_items'   => 10,
					'description' => '标签数组，6-10 个简短中文短语（2-6 字/词），常见可检索表达，不要 # / emoji / 长句。不存在时自动创建。',
				),
				'excerpt'         => array(
					'type'        => 'string',
					'required'    => false,
					'max_length'  => 200,
					'description' => '文章摘要（列表页展示用）。80-160 个汉字，与 meta_description 不重复，包含焦点关键词。',
				),
				'yoast_seo'      => array(
					'type'        => 'object',
					'required'    => false,
					'description' => 'Yoast SEO 字段（Google 收录关键）。插件未安装时会被忽略并提示。',
					'fields'      => array(
						'focus_keyword'    => array(
							'type'        => 'string',
							'required'    => false,
							'max_length'  => 30,
							'description' => '核心 SEO 关键词。2-6 个汉字的短词/短语，必须是用户在 Google 实际搜索的词；只输出 1 个最核心的。',
						),
						'seo_title'        => array(
							'type'        => 'string',
							'required'    => false,
							'max_length'  => 40,
							'description' => 'SEO 标题（Title Tag）。20-40 个汉字，含焦点关键词并靠前；Google 中文 SERP 标题展示宽度有限。',
						),
						'meta_description' => array(
							'type'        => 'string',
							'required'    => false,
							'max_length'  => 160,
							'description' => '元描述（Meta Description）。130-160 个汉字，焦点关键词自然出现 1-2 次，不堆砌；通顺完整句子，吸引点击。',
						),
					),
				),
			),
		);
	}

	/**
	 * 解析 JSON 字符串。
	 *
	 * @param string $json JSON 字符串。
	 * @return bool 是否解析成功。
	 */
	public function parse( $json ) {
		$this->errors   = array();
		$this->warnings = array();
		$this->data     = null;

		// 注意：此处不要再次调用 wp_unslash()。
		// WordPress wp_magic_quotes() 对 $_POST 自动 addslashes 的还原工作，
		// 必须在入口层（ajax_preview / handle_import_post）做一次且仅做一次。
		// 原因：parse() 有时会被入口层已还原的结果再次调用。
		$raw_original = (string) $json;
		$json = self::repair_json( $json );

		$decoded = json_decode( $json, true );

		// 二次容错尝试：若初次解析失败，尝试替换全角双引号/单引号并重试。
		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			$alt = str_replace( array( '“', '”', '‘', '’' ), array( '"', '"', "'", "'" ), $json );
			$alt_decoded = json_decode( $alt, true );
			if ( is_array( $alt_decoded ) ) {
				$decoded = $alt_decoded;
			}
		}

		// 三次容错尝试：正则降级字段提取器 (Fuzzy Extractor)，确保即使 JSON 语法严重受损也能提取出文章数据，安全创建草稿且绝不带入错误。
		if ( null === $decoded || ! is_array( $decoded ) ) {
			$fuzzy = self::fuzzy_extract_fields( $raw_original );
			if ( ! empty( $fuzzy['title'] ) && ! empty( $fuzzy['content'] ) ) {
				$decoded = $fuzzy;
				$this->warnings[] = __( '★ 智能容错提示：输入内容存在深层转义或语法瑕疵，系统已自动启用高级正则解析器安全提取标题与正文。草稿已安全建立，无任何格式污染。', 'wp-structured-draft-importer' );
			}
		}

		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			$err_msg   = json_last_error_msg();
			$err_code  = json_last_error();
			$code_info = '';
			if ( $err_code ) {
				$code_info = sprintf(
					/* translators: %d: JSON 错误代码。 */
					__( '（错误码 %d）', 'wp-structured-draft-importer' ),
					$err_code
				);
			}
			$this->errors[] = sprintf(
				/* translators: 1: JSON 解析错误信息, 2: 错误码信息。 */
				__( 'JSON 解析失败：%1$s%2$s。如含 Markdown 代码块标记，请点击「修复 JSON」按钮。', 'wp-structured-draft-importer' ),
				$err_msg,
				$code_info ? ' ' . $code_info : ''
			);
			return false;
		}

		if ( ! is_array( $decoded ) ) {
			$this->errors[] = __( '数据必须是 JSON 对象。', 'wp-structured-draft-importer' );
			return false;
		}

		$validated = $this->validate( $decoded );

		// 即使有校验错误也保留数据，便于预览展示。
		$this->data = $validated;

		return empty( $this->errors );
	}

	/**
	 * AI 输出 JSON 修复：处理常见的格式问题。
	 *
	 * 修复范围：
	 * - 清理 UTF-8 BOM 和零宽不可见字符
	 * - 提取 Markdown 代码块（```json ... ```）及剥离前导/后置闲聊文本
	 * - 智能提取最外层 { ... } 核心 JSON 对象
	 * - 非法反斜杠转义自动修复（如文件路径 C:\path 或正则 \d）
	 * - 字符串内未转义的换行符 / 回车 / 制表符
	 * - 字符串内未转义的双引号（特别是 HTML 属性 <a href="..."> 里的裸双引号）
	 * - 对象 / 数组末尾多余的逗号及连续多逗号
	 * - 注释 // 和 /* *\/ 剔除
	 * - 结构层全角标点（中文冒号、逗号）容错
	 *
	 * @param string $json 原始 JSON 字符串。
	 * @return string 修复后的 JSON 字符串。
	 */
	public static function repair_json( $json ) {
		$json = (string) $json;

		// 1. 清理开头的 UTF-8 BOM 和常见 Unicode 不见/零宽字符。
		$json = preg_replace( '/[\x{FEFF}\x{200B}-\x{200D}\x{200E}\x{200F}]/u', '', $json );

		// 2. 智能提取核心 JSON 区块（剥离 Markdown 代码块包装及前导/后置闲聊文本）。
		if ( preg_match( '/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/i', $json, $m ) ) {
			$json = $m[1];
		} elseif ( preg_match( '/```(?:json)?\s*\n?([\s\S]*)$/i', $json, $m ) && false !== strpos( $m[1], '{' ) ) {
			$json = $m[1];
		}

		// 提取最外层的 { ... }，剥离一切前置和后置闲聊说明或多余反引号。
		$first_brace = strpos( $json, '{' );
		$last_brace  = strrpos( $json, '}' );
		if ( false !== $first_brace && false !== $last_brace && $last_brace > $first_brace ) {
			$json = substr( $json, $first_brace, $last_brace - $first_brace + 1 );
		} elseif ( false !== $first_brace && false === $last_brace ) {
			$json = substr( $json, $first_brace ) . '}';
		}

		// 将 HTML 标签属性里的裸双引号转为单引号（如 <a href="url"> -> <a href='url'>），彻底杜绝破坏 JSON 字符串
		$json = preg_replace( '/(<(?:a|img|source|iframe|link)\b[^>]*?\s(?:href|src|class|id|target|rel|style)=)"([^"]*)"/i', "$1'$2'", $json );
		$json = preg_replace( '/(<(?:a|img|source|iframe|link)\b[^>]*?\s(?:href|src|class|id|target|rel|style)=)"([^"]*)"/i', "$1'$2'", $json );

		// 3. 逐字符扫描：在 JSON 字符串内部时，将未转义的控制字符与 HTML 属性双引号转为转义序列。
		$result    = '';
		$in_string = false;
		$escaped   = false;
		$len       = strlen( $json );

		for ( $i = 0; $i < $len; $i++ ) {
			$ch = $json[ $i ];

			if ( $in_string ) {
				if ( $escaped ) {
					$result   .= $ch;
					$escaped   = false;
					continue;
				}

				if ( '\\' === $ch ) {
					$next = isset( $json[ $i + 1 ] ) ? $json[ $i + 1 ] : '';
					if ( in_array( $next, array( '"', '\\', '/', 'b', 'f', 'n', 'r', 't' ), true ) ) {
						$result  .= $ch;
						$escaped  = true;
						continue;
					}
					if ( 'u' === $next ) {
						$hex = substr( $json, $i + 2, 4 );
						if ( preg_match( '/^[0-9a-fA-F]{4}$/', $hex ) ) {
							$result  .= $ch;
							$escaped  = true;
							continue;
						}
					}
					// 非法转义符（如普通反斜杠 C:\test 或 \d），自动转义为 \\
					$result .= '\\\\';
					continue;
				}

				if ( '"' === $ch ) {
					// 前瞻：跳过空白，判断后面是不是 JSON 结构字符。
					$j = $i + 1;
					while ( $j < $len ) {
						$nc = $json[ $j ];
						if ( ' ' === $nc || "\t" === $nc || "\n" === $nc || "\r" === $nc ) {
							$j++;
							continue;
						}
						break;
					}
					$next = ( $j < $len ) ? $json[ $j ] : '';
					// 合法的字符串结束符后面必须是 , } ] : 或 EOF。
					if ( '' === $next || ',' === $next || '}' === $next || ']' === $next || ':' === $next ) {
						$result    .= $ch;
						$in_string  = false;
						continue;
					}
					// 否则视为 HTML 属性内未转义的 "，转义为 \"，继续留在字符串内。
					$result .= '\\"';
					continue;
				}

				// 字符串内的控制字符 → 转义。
				$ord = ord( $ch );
				switch ( $ch ) {
					case "\n":
						$result .= '\\n';
						break;
					case "\r":
						$result .= '\\r';
						break;
					case "\t":
						$result .= '\\t';
						break;
					default:
						if ( $ord < 0x20 ) {
							$result .= sprintf( '\\u%04x', $ord );
						} else {
							$result .= $ch;
						}
						break;
				}
			} else {
				// 跳过注释 // 和 /* */
				if ( '/' === $ch && isset( $json[ $i + 1 ] ) ) {
					$next = $json[ $i + 1 ];
					if ( '/' === $next ) {
						// 行注释：跳到行尾。
						while ( $i < $len && "\n" !== $json[ $i ] ) {
							$i++;
						}
						$result .= "\n";
						continue;
					}
					if ( '*' === $next ) {
						// 块注释：跳到 */
						$i += 2;
						while ( $i < $len - 1 && ! ( '*' === $json[ $i ] && '/' === $json[ $i + 1 ] ) ) {
							$i++;
						}
						$i++; // 跳过 /
						continue;
					}
				}

				// 结构层：容错中文全角符号
				if ( '：' === $ch || ( isset( $json[ $i + 2 ] ) && "\xef\xbc\x9a" === substr( $json, $i, 3 ) ) ) {
					if ( "\xef\xbc\x9a" === substr( $json, $i, 3 ) ) {
						$i += 2;
					}
					$result .= ':';
					continue;
				}
				if ( '，' === $ch || ( isset( $json[ $i + 2 ] ) && "\xef\xbc\x8c" === substr( $json, $i, 3 ) ) ) {
					if ( "\xef\xbc\x8c" === substr( $json, $i, 3 ) ) {
						$i += 2;
					}
					$result .= ',';
					continue;
				}

				if ( '"' === $ch ) {
					$in_string = true;
					$result   .= $ch;
					continue;
				}

				$result .= $ch;
			}
		}

		// 移除连续多逗号与对象/数组末尾多余逗号。
		$result = preg_replace( '/,\s*,+/', ',', $result );
		$result = preg_replace( '/,\s*([\]}])/', '$1', $result );

		return $result;
	}

	/**
	 * 正则降级容错提取器：当 JSON 无法解析时，通过正则兜底提取各核心字段。
	 * 确保即使 AI 输出存在严重转义错误，也能安全导入草稿，绝不带入格式错误。
	 *
	 * @param string $raw 原始输入文本。
	 * @return array 提取出的字段数组。
	 */
	public static function fuzzy_extract_fields( $raw ) {
		$raw  = (string) $raw;
		$data = array();

		// 1. title
		if ( preg_match( '/"title"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/u', $raw, $m ) ) {
			$title         = str_replace( array( '\\"', '\\n', '\\r', '\\t' ), array( '"', "\n", '', "\t" ), $m[1] );
			$data['title'] = trim( str_replace( '`', '', $title ) );
		}

		// 2. content_format
		if ( preg_match( '/"content_format"\s*:\s*"(html|markdown)"/i', $raw, $m ) ) {
			$data['content_format'] = strtolower( $m[1] );
		} else {
			$data['content_format'] = 'html';
		}

		// 3. slug
		if ( preg_match( '/"slug"\s*:\s*"([a-zA-Z0-9\-_]+)"/', $raw, $m ) ) {
			$data['slug'] = $m[1];
		}

		// 4. excerpt
		if ( preg_match( '/"excerpt"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/u', $raw, $m ) ) {
			$data['excerpt'] = str_replace( array( '\\"', '\\n' ), array( '"', "\n" ), $m[1] );
		}

		// 5. tags
		if ( preg_match( '/"tags"\s*:\s*\[([\s\S]*?)\]/', $raw, $m ) ) {
			if ( preg_match_all( '/"((?:[^"\\\\]|\\\\.)*)"/u', $m[1], $tag_matches ) ) {
				$tags = array();
				foreach ( $tag_matches[1] as $t ) {
					$tags[] = str_replace( '\\"', '"', trim( $t ) );
				}
				$data['tags'] = array_values( array_filter( $tags ) );
			}
		}

		// 6. yoast_seo
		if ( preg_match( '/"yoast_seo"\s*:\s*\{([\s\S]*?)\}/u', $raw, $m ) ) {
			$y_raw = $m[1];
			$yoast = array();
			if ( preg_match( '/"focus_keyword"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/u', $y_raw, $ym ) ) {
				$yoast['focus_keyword'] = str_replace( '\\"', '"', $ym[1] );
			}
			if ( preg_match( '/"seo_title"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/u', $y_raw, $ym ) ) {
				$yoast['seo_title'] = str_replace( '\\"', '"', $ym[1] );
			}
			if ( preg_match( '/"meta_description"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/u', $y_raw, $ym ) ) {
				$yoast['meta_description'] = str_replace( '\\"', '"', $ym[1] );
			}
			if ( ! empty( $yoast ) ) {
				$data['yoast_seo'] = $yoast;
			}
		}

		// 7. content（核心提取）
		$content = '';
		if ( preg_match( '/"content"\s*:\s*"([\s\S]*?)"\s*,\s*"(?:content_format|slug|category|tags|excerpt|yoast_seo|source_text)"/u', $raw, $m ) ) {
			$content = $m[1];
		} elseif ( preg_match( '/"content"\s*:\s*"([\s\S]*?)"\s*\}\s*$/u', trim( $raw ), $m ) ) {
			$content = $m[1];
		} elseif ( preg_match( '/"content"\s*:\s*"([\s\S]*)/u', $raw, $m ) ) {
			$tail   = $m[1];
			$last_q = strrpos( $tail, '"' );
			if ( false !== $last_q ) {
				$content = substr( $tail, 0, $last_q );
			} else {
				$content = $tail;
			}
		}

		if ( $content ) {
			$content = str_replace( array( '\\"', '\\n', '\\r', '\\t' ), array( '"', "\n", '', "\t" ), $content );
			$content = preg_replace( '/^```[a-zA-Z]*\s*/i', '', $content );
			$content = preg_replace( '/\s*```$/', '', $content );
			$data['content'] = $content;
		}

		return $data;
	}

	/**
	 * 校验数据并清理。
	 *
	 * @param array $raw 原始数据。
	 * @return array 清理后的数据。
	 */
	protected function validate( $raw ) {
		$schema    = self::get_schema();
		$clean     = array();
		$all_fields = array_keys( $schema['fields'] );

		foreach ( $all_fields as $field ) {
			if ( ! isset( $raw[ $field ] ) ) {
				continue;
			}
			$clean[ $field ] = $raw[ $field ];
		}

		// 必填项。
		foreach ( $schema['required'] as $req ) {
			if ( ! isset( $clean[ $req ] ) || '' === trim( (string) $clean[ $req ] ) ) {
				$this->errors[] = sprintf(
					/* translators: %s: 字段名。 */
					__( '必填字段「%s」缺失或为空。', 'wp-structured-draft-importer' ),
					$req
				);
			}
		}

		// title 校验（自动截断超长，不阻断创建草稿）。
		if ( isset( $clean['title'] ) ) {
			$clean['title'] = sanitize_text_field( $clean['title'] );
			$len            = mb_strlen( $clean['title'] );
			if ( $len > 80 ) {
				$clean['title']   = mb_substr( $clean['title'], 0, 80 );
				$this->warnings[] = sprintf(
					/* translators: 1: 当前长度，2: 上限。 */
					__( '标题长度 %1$d 超过推荐上限 %2$d，已自动优化截断，草稿已成功建立。', 'wp-structured-draft-importer' ),
					$len,
					80
				);
			}
		}

		// content 必须为字符串。
		if ( isset( $clean['content'] ) && ! is_string( $clean['content'] ) ) {
			$this->errors[] = __( '字段「content」必须为字符串。', 'wp-structured-draft-importer' );
		}

		// content_format 校验。
		if ( isset( $clean['content_format'] ) ) {
			$clean['content_format'] = strtolower( sanitize_text_field( $clean['content_format'] ) );
			if ( ! in_array( $clean['content_format'], array( 'html', 'markdown' ), true ) ) {
				$clean['content_format'] = 'html';
			}
		} else {
			$clean['content_format'] = 'html';
		}

		// slug 校验：自动修剪至规范 kebab-case，超长自动截断，不阻断草稿创建。
		if ( ! empty( $clean['slug'] ) ) {
			$raw_slug  = (string) $clean['slug'];
			$sanitized = sanitize_title( $raw_slug );
			$sanitized = trim( preg_replace( '/[^a-z0-9\-]+/', '-', strtolower( $sanitized ) ), '-' );
			$sanitized = preg_replace( '/-+/', '-', $sanitized );
			if ( strlen( $sanitized ) > 60 ) {
				$sanitized        = rtrim( substr( $sanitized, 0, 60 ), '-' );
				$this->warnings[] = __( '固定链接 slug 超过 60 字符，已自动裁切为合规长度。', 'wp-structured-draft-importer' );
			}
			if ( '' === $sanitized ) {
				$sanitized = sanitize_title( isset( $clean['title'] ) ? $clean['title'] : 'draft' );
			}
			if ( $sanitized !== $raw_slug ) {
				$this->warnings[] = sprintf(
					/* translators: 1: 原值, 2: 新值。 */
					__( 'slug 原值「%1$s」已自动优化为合规格式「%2$s」。', 'wp-structured-draft-importer' ),
					esc_html( $raw_slug ),
					esc_html( $sanitized )
				);
			}
			$clean['slug'] = $sanitized;
		}

		// excerpt 校验（超长自动裁剪，不阻断草稿创建）。
		if ( isset( $clean['excerpt'] ) ) {
			$clean['excerpt'] = wp_strip_all_tags( (string) $clean['excerpt'] );
			$ex_len           = mb_strlen( $clean['excerpt'] );
			if ( $ex_len > 200 ) {
				$clean['excerpt'] = mb_substr( $clean['excerpt'], 0, 200 );
				$this->warnings[] = sprintf(
					/* translators: 1: 当前长度，2: 上限。 */
					__( '文章摘要长度 %1$d 超过上限 %2$d，已自动裁切保留前 200 字。', 'wp-structured-draft-importer' ),
					$ex_len,
					200
				);
			}
		}

		// tags 校验为数组（超量自动保留前 10 个，不阻断草稿创建）。
		if ( isset( $clean['tags'] ) ) {
			if ( ! is_array( $clean['tags'] ) ) {
				$clean['tags'] = array( $clean['tags'] );
			}
			$clean['tags'] = array_values( array_filter( array_map( 'sanitize_text_field', $clean['tags'] ) ) );
			$tag_count     = count( $clean['tags'] );
			if ( $tag_count > 10 ) {
				$clean['tags']    = array_slice( $clean['tags'], 0, 10 );
				$this->warnings[] = sprintf(
					/* translators: 1: 当前数量，2: 上限。 */
					__( '标签数量 %1$d 超过上限 %2$d，已自动保留前 10 个核心标签。', 'wp-structured-draft-importer' ),
					$tag_count,
					10
				);
			}
		}

		// yoast_seo 校验（超长自动裁剪，不阻断草稿创建）。
		if ( isset( $clean['yoast_seo'] ) ) {
			if ( ! is_array( $clean['yoast_seo'] ) ) {
				$this->warnings[]   = __( '字段「yoast_seo」不是合法对象，已忽略 SEO 字段。', 'wp-structured-draft-importer' );
				$clean['yoast_seo'] = array();
			} else {
				$yoast_clean  = array();
				$allowed_keys = array(
					'focus_keyword'    => 30,
					'seo_title'        => 40,
					'meta_description' => 160,
				);
				foreach ( $allowed_keys as $key => $max_len ) {
					if ( isset( $clean['yoast_seo'][ $key ] ) ) {
						$val  = sanitize_text_field( (string) $clean['yoast_seo'][ $key ] );
						$vlen = mb_strlen( $val );
						if ( $vlen > $max_len ) {
							$val              = mb_substr( $val, 0, $max_len );
							$this->warnings[] = sprintf(
								/* translators: 1: 字段名，2: 当前长度，3: 上限。 */
								__( '字段「yoast_seo.%1$s」长度 %2$d 超过上限 %3$d，已自动裁剪。', 'wp-structured-draft-importer' ),
								$key,
								$vlen,
								$max_len
							);
						}
						$yoast_clean[ $key ] = $val;
					}
				}
				$clean['yoast_seo'] = $yoast_clean;
			}
		}

		// source_text 校验（可选，清理即可）。
		if ( isset( $clean['source_text'] ) ) {
			$clean['source_text'] = sanitize_textarea_field( (string) $clean['source_text'] );
		}

		// 自动修复：content 声明 html 但实际是纯文本时，自动包裹 HTML 标签。
		// 必须在 run_quality_checks 之前执行，这样质量检查看到的是修复后的结果。
		if ( isset( $clean['content'] ) ) {
			$fmt     = $clean['content_format'] ?? 'html';
			$has_tag = (bool) preg_match( '/<[a-z][^>]*>/i', (string) $clean['content'] );
			if ( 'html' === $fmt && ! $has_tag && ! empty( $clean['content'] ) ) {
				$clean['content'] = $this->auto_htmlify( (string) $clean['content'] );
				$this->warnings[] = __( '★ 自动修复：content 声明为 html 但实际是纯文本（无任何 HTML 标签）。已自动为段落添加 <p>、为疑似标题添加 <h2>。建议检查预览效果，必要时手动补充 <table>/<ul>/<strong> 等标签。', 'wp-structured-draft-importer' );
			}
		}

		// ===== 质量校验（仅产生 warnings，不阻塞导入） =====
		$this->run_quality_checks( $clean );

		return $clean;
	}

	/**
	 * 质量校验：检测 AI 输出常见问题，以 warnings 形式提示。
	 *
	 * @param array $clean 已清理的数据。
	 * @return void
	 */
	protected function run_quality_checks( $clean ) {
		// 1. HTML 模式下检测纯文本 content（无 HTML 标签）。
		//    注意：parse() 中已对纯文本做了 auto_htmlify 兜底，此处检查的是修复后的结果。
		if ( isset( $clean['content'] ) && 'html' === ( $clean['content_format'] ?? 'html' ) ) {
			$content  = (string) $clean['content'];
			$has_tags = (bool) preg_match( '/<[a-z][^>]*>/i', $content );
			if ( ! $has_tags ) {
				$this->warnings[] = __( 'content 声明为 html 但未检测到任何 HTML 标签，正文可能为纯文本。插件已尝试自动修复，建议检查预览效果。', 'wp-structured-draft-importer' );
			}

			// 2. 检测 Markdown 脚注/引用式链接。
			if ( preg_match( '/\[\d+\]:\s*https?/i', $content ) ) {
				$this->warnings[] = __( 'content 中检测到 Markdown 脚注（如 [1]: https://...），这些内容会原样出现在文章末尾。请改用 <a> 标签内联链接。', 'wp-structured-draft-importer' );
			}
			if ( preg_match( '/\[([^\]]+)\]\[(\d+)\]/', $content ) ) {
				$this->warnings[] = __( 'content 中检测到 Markdown 引用式链接（如 [文本][1]），不会被渲染为可点击链接。请改用 <a href="...">文本</a>。', 'wp-structured-draft-importer' );
			}

			// 3. 检测裸 n 字符（AI 把 \n 写成了 n）。
			if ( preg_match( '/[\p{Han}]n[\p{Han}]/u', $content ) ) {
				$this->warnings[] = __( 'content 中检测到疑似裸 "n" 字符（如「洗牌n在」），可能是 AI 未正确转义换行符。建议在编辑器中点击「修复 JSON」重试。', 'wp-structured-draft-importer' );
			}
		}

		// 4. title 与 seo_title 过于相似。
		if ( isset( $clean['title'] ) && isset( $clean['yoast_seo']['seo_title'] ) ) {
			$title  = $clean['title'];
			$seo    = $clean['yoast_seo']['seo_title'];
			$sim    = $this->similarity( $title, $seo );
			if ( $sim > 0.85 ) {
				$this->warnings[] = sprintf(
					/* translators: %d: 相似度百分比。 */
					__( 'title 与 yoast_seo.seo_title 相似度约 %d%%，几乎完全相同。建议 title 偏 H1 主标题（可含副标题），seo_title 偏搜索结果标题，两者应有所区分。', 'wp-structured-draft-importer' ),
					(int) round( $sim * 100 )
				);
			}
		}

		// 5. excerpt 与 meta_description 过于相似。
		if ( isset( $clean['excerpt'] ) && isset( $clean['yoast_seo']['meta_description'] ) ) {
			$exc     = $clean['excerpt'];
			$meta    = $clean['yoast_seo']['meta_description'];
			$sim     = $this->similarity( $exc, $meta );
			if ( $sim > 0.85 ) {
				$this->warnings[] = sprintf(
					/* translators: %d: 相似度百分比。 */
					__( 'excerpt 与 meta_description 相似度约 %d%%，几乎完全相同。excerpt 偏列表页摘要，meta_description 偏搜索结果，应避免重复。', 'wp-structured-draft-importer' ),
					(int) round( $sim * 100 )
				);
			}
		}

		// 6. content 过短。
		if ( isset( $clean['content'] ) ) {
			$text_only = trim( preg_replace( '/<[^>]+>/', '', (string) $clean['content'] ) );
			if ( mb_strlen( $text_only ) < 300 ) {
				$this->warnings[] = __( 'content 正文纯文本不足 300 字，内容可能过于单薄。建议补充到 800 字以上。', 'wp-structured-draft-importer' );
			}
		}
	}

	/**
	 * 将纯文本 content 自动包裹为基本 HTML 结构。
	 *
	 * 当 AI 忽略「必须纯 HTML」的提示词、输出用 \n 分隔的纯文本时，
	 * 此方法作为兜底：将短行识别为 h2 标题，长行包裹为 p 段落。
	 * 无法完美还原表格/列表（已被 AI 压平的），但至少保证基本段落结构。
	 *
	 * @param string $text 纯文本内容。
	 * @return string HTML 内容。
	 */
	protected function auto_htmlify( $text ) {
		$text  = (string) $text;
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$html  = '';
		$para  = array(); // 当前段落缓冲（连续非空行）。

		$flush_para = function() use ( &$html, &$para ) {
			if ( ! empty( $para ) ) {
				$html .= '<p>' . implode( "<br>\n", $para ) . "</p>\n";
				$para  = array();
			}
		};

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				// 空行 → 段落分隔。
				$flush_para();
				continue;
			}

			// 判断是否像标题：
			// - 短（≤45字）
			// - 不以句号/逗号等结尾（但允许 ？ 问号结尾，疑问式标题很常见）
			// - 不以列表符号开头
			// - 不以常见句首词开头（在/从/对/这/那/随/当/为/由/据/按/经/而/但/不/如/此/它/他/她/其）
			// - 优先识别含冒号「：」的行（中文标题常见格式）
			$len             = mb_strlen( $line );
			$ends_with_stop  = preg_match( '/[。，；、！.!?…]$/', $line );
			$is_list_item    = preg_match( '/^[-*•·\d]+[.、)]\s/', $line );
			$starts_sentence = preg_match( '/^(在|从|对|这|那|随|当|为|由|据|按|经|而|但|不|如|此|它|他|她|其|要|由|如果|因为|所以|不过|虽然|尽管|值得|可以|能够|需要|已经|目前|现在|近期|近期|过去|本次|这次|此次)/', $line );
			$has_colon       = ( false !== mb_strpos( $line, '：' ) || false !== strpos( $line, ':' ) );

			// 标题判定：短行 + 不以句号结尾 + 不以列表符号开头 + 不以句首词开头
			// 特殊处理：以？结尾的短行也算标题（疑问式标题），但不含逗号
			$ends_with_question = preg_match( '/[？?]$/', $line );
			$has_comma          = ( false !== mb_strpos( $line, '，' ) || false !== strpos( $line, ',' ) );

			$is_heading = (
				$len <= 45 &&
				! $is_list_item &&
				! $starts_sentence &&
				( $has_colon || ( $ends_with_question && ! $has_comma ) || ( ! $ends_with_stop && $len <= 30 ) )
			);

			if ( $is_heading ) {
				$flush_para();
				$html .= '<h2>' . $line . "</h2>\n";
			} else {
				$para[] = $line;
			}
		}
		$flush_para();

		return trim( $html );
	}

	/**
	 * 计算两个字符串的相似度（0-1，基于最长公共子序列比率）。
	 *
	 * @param string $a 字符串 A。
	 * @param string $b 字符串 B。
	 * @return float 相似度 0-1。
	 */
	protected function similarity( $a, $b ) {
		$a  = mb_strtolower( trim( $a ) );
		$b  = mb_strtolower( trim( $b ) );
		$la = mb_strlen( $a );
		$lb = mb_strlen( $b );
		if ( 0 === $la || 0 === $lb ) {
			return 0.0;
		}
		// 简化版：用 common_substring 比率。
		$max_len = max( $la, $lb );
		// 快速检测：如果一个完全包含另一个，直接给高分。
		if ( false !== mb_strpos( $a, $b ) || false !== mb_strpos( $b, $a ) ) {
			return min( $la, $lb ) / $max_len;
		}
		// 计算字符重叠率（简化）。
		$common = 0;
		$len    = min( $la, $lb );
		for ( $i = 0; $i < $len; $i++ ) {
			if ( mb_substr( $a, $i, 1 ) === mb_substr( $b, $i, 1 ) ) {
				$common++;
			}
		}
		return $common / $max_len;
	}

	/**
	 * 返回最近一次错误列表。
	 *
	 * @return string[]
	 */
	public function get_errors() {
		return $this->errors;
	}

	/**
	 * 返回最近一次警告列表（不阻塞导入）。
	 *
	 * @return string[]
	 */
	public function get_warnings() {
		return $this->warnings;
	}

	/**
	 * 返回解析后的数据。
	 *
	 * @return array|null
	 */
	public function get_data() {
		return $this->data;
	}

	/**
	 * 执行导入并创建草稿。
	 *
	 * @return array{success:bool, post_id?:int, edit_url?:string, warnings?:string[]}
	 */
	public function import() {
		if ( null === $this->data ) {
			return array(
				'success' => false,
				'errors'  => array( __( '无可导入数据，请先解析 JSON。', 'wp-structured-draft-importer' ) ),
			);
		}

		if ( ! empty( $this->errors ) ) {
			return array(
				'success' => false,
				'errors'  => $this->errors,
			);
		}

		$warnings = array();
		$data     = $this->data;

		// 合并质量校验 warnings。
		$warnings = array_merge( $warnings, $this->warnings );

		// 处理正文格式。
		$content = (string) $data['content'];
		if ( 'markdown' === $data['content_format'] ) {
			$content = $this->markdown_to_html( $content );
		} else {
			$content = wp_kses_post( $this->balance_html( $content ) );
		}

		// 处理分类：只接受站点已存在的分类，绝不自动创建。
		$post_category = array();
		if ( isset( $data['category'] ) && '' !== (string) $data['category'] ) {
			$cat_id = $this->resolve_category( $data['category'] );
			if ( $cat_id ) {
				$post_category[] = $cat_id;
			} else {
				// translators: %s 是用户提供的分类原始值（名称或 ID）
				$warnings[] = sprintf(
					__( '指定的分类「%s」在当前站点不存在，已跳过（插件不会自动创建新分类；请先在 WordPress 后台建好该分类，或留空分类字段）。', 'wp-structured-draft-importer' ),
					esc_html( (string) $data['category'] )
				);
			}
		}

		// 处理标签：tags_input 直接用名称数组，WP 会自动创建。
		$tags_input = isset( $data['tags'] ) ? $data['tags'] : array();

		// 准备草稿数据（严格净化，绝不带入任何反引号、代码块标记或破坏性字符）。
		$clean_title   = trim( str_replace( array( '`', '```json', '```' ), '', (string) $data['title'] ) );
		$clean_content = preg_replace( '/^```[a-zA-Z]*\s*/i', '', $content );
		$clean_content = preg_replace( '/\s*```$/', '', $clean_content );
		$clean_slug    = isset( $data['slug'] ) && '' !== $data['slug'] ? sanitize_title( str_replace( '`', '', $data['slug'] ) ) : sanitize_title( $clean_title );
		$clean_excerpt = isset( $data['excerpt'] ) ? str_replace( '`', '', (string) $data['excerpt'] ) : '';

		$postarr = array(
			'post_title'   => $clean_title,
			'post_content' => $clean_content,
			'post_status'  => 'draft',
			'post_type'    => 'post',
			'post_name'    => $clean_slug,
			'post_excerpt' => $clean_excerpt,
		);
		if ( ! empty( $post_category ) ) {
			$postarr['post_category'] = $post_category;
		}
		if ( ! empty( $tags_input ) ) {
			$postarr['tags_input'] = $tags_input;
		}

		// 移除 Kses 与 title 过滤器以避免富文本被剥离。
		$this->pause_kses_filters();

		$post_id = wp_insert_post( wp_slash( $postarr ), true );

		$this->restore_kses_filters();

		if ( is_wp_error( $post_id ) ) {
			return array(
				'success' => false,
				'errors'  => array( $post_id->get_error_message() ),
			);
		}
		if ( 0 === $post_id ) {
			return array(
				'success' => false,
				'errors'  => array( __( '创建草稿失败：未知错误。', 'wp-structured-draft-importer' ) ),
			);
		}

		// 写入 Yoast SEO meta。
		if ( ! empty( $data['yoast_seo'] ) ) {
			if ( self::is_yoast_active() ) {
				$this->write_yoast_meta( $post_id, $data['yoast_seo'] );
			} else {
				$warnings[] = __( '未检测到 Yoast SEO 插件，已跳过 SEO 字段。', 'wp-structured-draft-importer' );
			}
		}

		return array(
			'success'  => true,
			'post_id'  => (int) $post_id,
			'edit_url' => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
			'view_url' => get_permalink( $post_id ),
			'warnings' => $warnings,
		);
	}

	/**
	 * 解析分类名称或 ID 为分类 ID。
	 * 重要：只使用站点内已经存在的分类，**绝不自动创建新分类**。
	 * 若用户提供的分类（名称 / ID / slug）都无法在现有分类中匹配，
	 * 返回 null，由上层生成 warning 并跳过分类分配。
	 *
	 * @param mixed $category 分类名称（字符串）或分类 ID（整数）。
	 * @return int|null 成功匹配的 term_id，或 null。
	 */
	protected function resolve_category( $category ) {
		// 纯数字按 ID 处理。
		if ( is_numeric( $category ) && (int) $category > 0 ) {
			$cat = (int) $category;
			$_t  = get_term( $cat, 'category' );
			if ( $_t && ! is_wp_error( $_t ) ) {
				return $cat;
			}
			return null;
		}

		$name = sanitize_text_field( (string) $category );
		if ( '' === $name ) {
			return null;
		}

		// 按 slug 查找（兼容用户写的 slug 字符串）。
		$slug = sanitize_title( $name );
		$term = get_term_by( 'slug', $slug, 'category' );
		if ( $term ) {
			return (int) $term->term_id;
		}

		// 按名称查找（最常用）。
		$term = get_term_by( 'name', $name, 'category' );
		if ( $term ) {
			return (int) $term->term_id;
		}

		// 不再调用 wp_insert_term() 自动创建分类。
		// 用户明确要求：只能选用 WP 已存在的分类，或空着让他手动选。
		return null;
	}

	/**
	 * 写入 Yoast SEO 元数据。
	 *
	 * @param int   $post_id 文章 ID。
	 * @param array $yoast   Yoast 字段数组。
	 * @return void
	 */
	protected function write_yoast_meta( $post_id, $yoast ) {
		$map = array(
			'focus_keyword'    => '_yoast_wpseo_focuskw',
			'seo_title'        => '_yoast_wpseo_title',
			'meta_description' => '_yoast_wpseo_metadesc',
		);

		foreach ( $map as $field => $meta_key ) {
			if ( ! isset( $yoast[ $field ] ) ) {
				continue;
			}
			$value = (string) $yoast[ $field ];
			if ( '' !== $value ) {
				update_post_meta( $post_id, $meta_key, $value );
			}
		}
	}

	/**
	 * 暂停 Kses 与相关过滤器，防止内容被剥离。
	 *
	 * @return void
	 */
	protected function pause_kses_filters() {
		if ( function_exists( 'kses_remove_filters' ) ) {
			kses_remove_filters();
		}
		remove_filter( 'content_save_pre', 'wp_filter_post_kses' );
	}

	/**
	 * 恢复 Kses 过滤器。
	 *
	 * @return void
	 */
	protected function restore_kses_filters() {
		if ( function_exists( 'kses_init_filters' ) ) {
			kses_init_filters();
		}
	}

	/**
	 * 简易 HTML 标签平衡。
	 *
	 * @param string $html HTML 字符串。
	 * @return string
	 */
	protected function balance_html( $html ) {
		return force_balance_tags( $html );
	}

	/**
	 * 简易 Markdown 转 HTML（不依赖外部库）。
	 * 支持：标题、粗体、斜体、链接、列表、代码块、段落。
	 *
	 * @param string $markdown Markdown 字符串。
	 * @return string HTML。
	 */
	protected function markdown_to_html( $markdown ) {
		$text = $markdown;

		// 代码块 ```lang\n...```\n。
		$text = preg_replace_callback(
			'/```(\w*)\n(.*?)```/s',
			function ( $m ) {
				$lang = ! empty( $m[1] ) ? ' data-lang="' . esc_attr( $m[1] ) . '"' : '';
				return '<pre class="wp-block-code"' . $lang . '><code>' . esc_html( $m[2] ) . '</code></pre>';
			},
			$text
		);

		// 标题 ### / ## / #。
		$text = preg_replace_callback(
			'/^(#{1,6})\s+(.*)$/m',
			function ( $m ) {
				$level = strlen( $m[1] );
				return '<h' . $level . '>' . esc_html( trim( $m[2] ) ) . '</h' . $level . '>';
			},
			$text
		);

		// 链接 [text](url)。
		$text = preg_replace_callback(
			'/\[([^\]]+)\]\(([^)\s]+)\)/',
			function ( $m ) {
				$url   = esc_url( $m[2] );
				$title = esc_html( $m[1] );
				return '<a href="' . $url . '">' . $title . '</a>';
			},
			$text
		);

		// 粗体 **text**。
		$text = preg_replace( '/\*\*([^\*]+)\*\*/', '<strong>$1</strong>', $text );

		// 斜体 *text*。
		$text = preg_replace( '/\*([^\*]+)\*/', '<em>$1</em>', $text );

		// 无序列表。
		$text = preg_replace_callback(
			'/^(?:[-*]\s+.+\n?)+/m',
			function ( $m ) {
				$items = preg_split( '/^[-*]\s+/m', trim( $m[0] ) );
				$items = array_filter( $items );
				$out   = '<ul>';
				foreach ( $items as $item ) {
					$out .= '<li>' . trim( $item ) . '</li>';
				}
				return $out . '</ul>';
			},
			$text
		);

		// 段落：双换行分段。
		$blocks = preg_split( '/\n{2,}/', trim( $text ) );
		$html   = '';
		foreach ( $blocks as $block ) {
			$block = trim( $block );
			if ( '' === $block ) {
				continue;
			}
			// 跳过已是块级标签的内容。
			if ( preg_match( '/^<(h[1-6]|ul|ol|pre|blockquote|p|div)/i', $block ) ) {
				$html .= $block . "\n";
			} else {
				$block = nl2br( $block );
				$html  .= '<p>' . $block . '</p>' . "\n";
			}
		}

		return force_balance_tags( $html );
	}
}
