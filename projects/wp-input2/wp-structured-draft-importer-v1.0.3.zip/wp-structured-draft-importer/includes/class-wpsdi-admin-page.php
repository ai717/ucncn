<?php
/**
 * 管理后台页面：菜单、资源、UI 渲染与 AJAX。
 *
 * @package WpStructuredDraftImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPSDI_Admin_Page
 */
class WPSDI_Admin_Page {

	/**
	 * 菜单 slug。
	 *
	 * @var string
	 */
	const SLUG = 'wpsdi-import';

	/**
	 * AJAX 校验 nonce action。
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'wpsdi-import-nonce';

	/**
	 * 用户选项 key（最近输入）。
	 *
	 * @var string
	 */
	const OPTION_LAST_JSON = 'wpsdi_last_json';

	/**
	 * 构造：注册钩子。
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_wpsdi_import', array( $this, 'handle_import_post' ) );
		add_action( 'wp_ajax_wpsdi_preview', array( $this, 'ajax_preview' ) );
	}

	/**
	 * 注册后台菜单。
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			__( '结构化草稿导入', 'wp-structured-draft-importer' ),
			__( '草稿导入器', 'wp-structured-draft-importer' ),
			'edit_posts',
			self::SLUG,
			array( $this, 'render_page' ),
			'dashicons-media-text',
			26
		);
	}

	/**
	 * 加载资源。
	 *
	 * @param string $hook 当前页面 hook。
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}

		$css_ver = file_exists( WPSDI_PLUGIN_DIR . 'assets/css/admin.css' ) ? (string) filemtime( WPSDI_PLUGIN_DIR . 'assets/css/admin.css' ) : WPSDI_VERSION;
		$js_ver  = file_exists( WPSDI_PLUGIN_DIR . 'assets/js/admin.js' ) ? (string) filemtime( WPSDI_PLUGIN_DIR . 'assets/js/admin.js' ) : WPSDI_VERSION;

		wp_enqueue_style(
			'wpsdi-admin',
			WPSDI_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			$css_ver
		);

		wp_enqueue_script(
			'wpsdi-admin',
			WPSDI_PLUGIN_URL . 'assets/js/admin.js',
			array( 'wp-util', 'jquery' ),
			$js_ver,
			true
		);

		wp_localize_script(
			'wpsdi-admin',
			'WPSDI',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( self::NONCE_ACTION ),
				'previewAction'  => 'wpsdi_preview',
				'schema'         => WPSDI_Importer::get_schema(),
				'isYoastActive'  => WPSDI_Importer::is_yoast_active(),
				'i18n'           => array(
					'empty'           => __( '请先粘贴 JSON 数据。', 'wp-structured-draft-importer' ),
					'invalidJson'      => __( 'JSON 格式错误：', 'wp-structured-draft-importer' ),
					'valid'           => __( 'JSON 语法正确，可预览或导入。', 'wp-structured-draft-importer' ),
					'previewTitle'    => __( '解析预览', 'wp-structured-draft-importer' ),
					'importing'       => __( '正在导入…', 'wp-structured-draft-importer' ),
					'imported'       => __( '草稿已创建。', 'wp-structured-draft-importer' ),
					'copyOk'         => __( '已复制', 'wp-structured-draft-importer' ),
					'copyFail'       => __( '复制失败', 'wp-structured-draft-importer' ),
					'noData'         => __( '无可预览数据。', 'wp-structured-draft-importer' ),
					'fields'         => array(
						'title'          => __( '标题', 'wp-structured-draft-importer' ),
						'content'        => __( '正文', 'wp-structured-draft-importer' ),
						'content_format' => __( '正文格式', 'wp-structured-draft-importer' ),
						'slug'           => __( '固定链接 Slug', 'wp-structured-draft-importer' ),
						'category'       => __( '分类', 'wp-structured-draft-importer' ),
						'tags'           => __( '标签', 'wp-structured-draft-importer' ),
						'excerpt'        => __( '摘要', 'wp-structured-draft-importer' ),
						'yoast_seo'      => __( 'Yoast SEO', 'wp-structured-draft-importer' ),
						'focus_keyword'  => __( '焦点关键词', 'wp-structured-draft-importer' ),
						'seo_title'      => __( 'SEO 标题', 'wp-structured-draft-importer' ),
						'meta_description' => __( '元描述', 'wp-structured-draft-importer' ),
					),
				),
			)
		);
	}

	/**
	 * 渲染后台页面。
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( '权限不足。', 'wp-structured-draft-importer' ) );
		}

		$schema = WPSDI_Importer::get_schema();
		$yoast  = WPSDI_Importer::is_yoast_active();
		$last   = get_user_meta( get_current_user_id(), self::OPTION_LAST_JSON, true );

		// 处理导入结果提示。
		$flash = $this->take_flash();
		?>
		<div class="wrap wpsdi-wrap">
			<header class="wpsdi-header">
				<div class="wpsdi-header__brand">
					<span class="wpsdi-logo" aria-hidden="true">
						<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
							<polyline points="14 2 14 8 20 8"></polyline>
							<line x1="9" y1="13" x2="15" y2="13"></line>
							<line x1="9" y1="17" x2="15" y2="17"></line>
						</svg>
					</span>
					<div>
						<h1><?php echo esc_html__( '结构化草稿导入器', 'wp-structured-draft-importer' ); ?></h1>
						<p class="wpsdi-header__sub">
							<?php echo esc_html__( '一键将 AI 生成的结构化 JSON 转为 WordPress 草稿。', 'wp-structured-draft-importer' ); ?>
						</p>
					</div>
				</div>
				<div class="wpsdi-header__status">
					<?php if ( $yoast ) : ?>
						<span class="wpsdi-badge wpsdi-badge--ok"><?php esc_html_e( 'Yoast SEO 已激活', 'wp-structured-draft-importer' ); ?></span>
					<?php else : ?>
						<span class="wpsdi-badge wpsdi-badge--warn"><?php esc_html_e( '未检测到 Yoast SEO', 'wp-structured-draft-importer' ); ?></span>
					<?php endif; ?>
					<span class="wpsdi-badge wpsdi-badge--info">Schema v<?php echo esc_html( $schema['version'] ); ?></span>
				</div>
			</header>

			<?php if ( $flash ) : ?>
				<div class="wpsdi-flash wpsdi-flash--<?php echo esc_attr( $flash['type'] ); ?>" role="status">
					<?php if ( 'success' === $flash['type'] ) : ?>
						<span class="dashicons dashicons-yes-alt"></span>
					<?php else : ?>
						<span class="dashicons dashicons-warning"></span>
					<?php endif; ?>
					<div class="wpsdi-flash__body">
						<strong><?php echo esc_html( $flash['title'] ); ?></strong>
						<ul>
							<?php foreach ( $flash['messages'] as $msg ) : ?>
								<li><?php echo wp_kses_post( $msg ); ?></li>
							<?php endforeach; ?>
						</ul>
						<?php if ( ! empty( $flash['edit_url'] ) ) : ?>
							<a class="button button-primary button-small" href="<?php echo esc_url( $flash['edit_url'] ); ?>">
								<?php esc_html_e( '编辑此草稿', 'wp-structured-draft-importer' ); ?>
							</a>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<nav class="wpsdi-tabs" role="tablist">
				<button class="wpsdi-tabs__btn is-active" data-tab="import" role="tab" aria-selected="true">
					<?php esc_html_e( '导入草稿', 'wp-structured-draft-importer' ); ?>
				</button>
				<button class="wpsdi-tabs__btn" data-tab="schema" role="tab" aria-selected="false">
					<?php esc_html_e( '数据规范', 'wp-structured-draft-importer' ); ?>
				</button>
				<button class="wpsdi-tabs__btn" data-tab="ai" role="tab" aria-selected="false">
					<?php esc_html_e( 'AI 提示词', 'wp-structured-draft-importer' ); ?>
				</button>
			</nav>

			<section class="wpsdi-panel is-active" data-panel="import">
				<div class="wpsdi-grid">
					<div class="wpsdi-grid__col wpsdi-grid__col--input">
						<div class="wpsdi-card">
							<div class="wpsdi-card__head">
								<h2><?php esc_html_e( 'JSON 输入', 'wp-structured-draft-importer' ); ?></h2>
								<div class="wpsdi-card__tools">
									<button type="button" class="wpsdi-btn wpsdi-btn--ghost" id="wpsdi-repair">
										<span class="dashicons dashicons-wrench" style="font-size:14px;width:14px;height:14px"></span>
										<?php esc_html_e( '修复 JSON', 'wp-structured-draft-importer' ); ?>
									</button>
									<button type="button" class="wpsdi-btn wpsdi-btn--ghost" id="wpsdi-format"><?php esc_html_e( '格式化', 'wp-structured-draft-importer' ); ?></button>
									<button type="button" class="wpsdi-btn wpsdi-btn--ghost" id="wpsdi-clear"><?php esc_html_e( '清空', 'wp-structured-draft-importer' ); ?></button>
								</div>
							</div>
							<div class="wpsdi-card__body">
								<textarea id="wpsdi-json" class="wpsdi-textarea" spellcheck="false" placeholder="<?php echo esc_attr( $this->placeholder_json() ); ?>"><?php echo esc_textarea( $last ? $last : '' ); ?></textarea>
								<div class="wpsdi-status" id="wpsdi-status" role="status" aria-live="polite"></div>
							</div>
							<div class="wpsdi-card__foot">
								<button type="button" class="button button-secondary" id="wpsdi-preview-btn">
									<span class="dashicons dashicons-visibility"></span>
									<?php esc_html_e( '解析预览', 'wp-structured-draft-importer' ); ?>
								</button>
								<button type="button" class="button button-primary" id="wpsdi-import-btn">
									<span class="dashicons dashicons-upload"></span>
									<?php esc_html_e( '创建草稿', 'wp-structured-draft-importer' ); ?>
								</button>
							</div>
						</div>

						<div class="wpsdi-card" style="margin-top:16px">
							<div class="wpsdi-card__head">
								<h2><?php esc_html_e( '原文输入（可选，用于改写模式）', 'wp-structured-draft-importer' ); ?></h2>
								<span class="wpsdi-card__hint"><?php esc_html_e( '粘贴原文后，AI 会基于原文理解、优化、丰富内容，而非从零创作。将原文写入 source_text 字段即可。', 'wp-structured-draft-importer' ); ?></span>
							</div>
							<div class="wpsdi-card__body">
								<textarea id="wpsdi-source" class="wpsdi-textarea" spellcheck="false" style="min-height:140px" placeholder="<?php esc_attr_e( '在此粘贴原文，或直接在 JSON 的 source_text 字段中填写…', 'wp-structured-draft-importer' ); ?>"></textarea>
								<p class="description" style="margin-top:8px">
									<?php esc_html_e( '💡 在 AI 提示词中勾选「基于原文改写」模式，将此原文粘贴给 AI，它会输出包含 source_text 的 JSON。', 'wp-structured-draft-importer' ); ?>
								</p>
							</div>
						</div>
					</div>
					<div class="wpsdi-grid__col wpsdi-grid__col--preview">
						<div class="wpsdi-card">
							<div class="wpsdi-card__head">
								<h2><?php esc_html_e( '解析预览', 'wp-structured-draft-importer' ); ?></h2>
								<span class="wpsdi-card__hint" id="wpsdi-preview-hint"><?php esc_html_e( '点击「解析预览」按钮查看字段。', 'wp-structured-draft-importer' ); ?></span>
							</div>
							<div class="wpsdi-card__body">
								<div id="wpsdi-preview" class="wpsdi-preview">
									<div class="wpsdi-preview__empty">
										<span class="dashicons dashicons-media-document"></span>
										<p><?php esc_html_e( '解析后将在此展示字段。', 'wp-structured-draft-importer' ); ?></p>
									</div>
								</div>
								<div id="wpsdi-warnings" class="wpsdi-warnings" style="display:none;margin-top:16px"></div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section class="wpsdi-panel" data-panel="schema">
				<?php $this->render_schema_tab( $schema ); ?>
			</section>

			<section class="wpsdi-panel" data-panel="ai">
				<?php $this->render_ai_tab(); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * 渲染 Schema 说明 Tab。
	 *
	 * @param array $schema Schema 数组。
	 * @return void
	 */
	protected function render_schema_tab( $schema ) {
		$fields = $schema['fields'];
		?>
		<div class="wpsdi-card">
			<div class="wpsdi-card__head">
				<h2><?php esc_html_e( '结构化数据规范', 'wp-structured-draft-importer' ); ?></h2>
				<span class="wpsdi-badge wpsdi-badge--info">v<?php echo esc_html( $schema['version'] ); ?></span>
			</div>
			<div class="wpsdi-card__body">
				<p class="wpsdi-lead">
					<?php
					echo wp_kses(
						__( '所有字段使用 <strong>UTF-8</strong> 编码的 <strong>JSON</strong>。除 <code>title</code> 与 <code>content</code> 必填外，其余字段可省略；省略的字段不会覆盖原值。', 'wp-structured-draft-importer' ),
						array( 'strong' => array(), 'code' => array() )
					);
					?>
				</p>
				<table class="wpsdi-table">
					<thead>
						<tr>
							<th><?php esc_html_e( '字段', 'wp-structured-draft-importer' ); ?></th>
							<th><?php esc_html_e( '类型', 'wp-structured-draft-importer' ); ?></th>
							<th><?php esc_html_e( '必填', 'wp-structured-draft-importer' ); ?></th>
							<th><?php esc_html_e( '说明', 'wp-structured-draft-importer' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $fields as $key => $spec ) : ?>
							<tr>
								<td><code><?php echo esc_html( $key ); ?></code></td>
								<td><?php echo esc_html( isset( $spec['type'] ) ? $spec['type'] : '—' ); ?></td>
								<td>
									<?php if ( in_array( $key, $schema['required'], true ) ) : ?>
										<span class="wpsdi-pill wpsdi-pill--danger"><?php esc_html_e( '必填', 'wp-structured-draft-importer' ); ?></span>
									<?php else : ?>
										<span class="wpsdi-pill wpsdi-pill--muted"><?php esc_html_e( '可选', 'wp-structured-draft-importer' ); ?></span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( isset( $spec['description'] ) ? $spec['description'] : '' ); ?></td>
							</tr>
							<?php if ( 'yoast_seo' === $key && ! empty( $spec['fields'] ) ) : ?>
								<?php foreach ( $spec['fields'] as $ykey => $yspec ) : ?>
									<tr class="wpsdi-table__sub">
										<td><code>yoast_seo.<?php echo esc_html( $ykey ); ?></code></td>
										<td><?php echo esc_html( isset( $yspec['type'] ) ? $yspec['type'] : '—' ); ?></td>
										<td><span class="wpsdi-pill wpsdi-pill--muted"><?php esc_html_e( '可选', 'wp-structured-draft-importer' ); ?></span></td>
										<td><?php echo esc_html( isset( $yspec['description'] ) ? $yspec['description'] : '' ); ?></td>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>
						<?php endforeach; ?>
					</tbody>
				</table>

				<h3 class="wpsdi-h3"><?php esc_html_e( '完整示例', 'wp-structured-draft-importer' ); ?></h3>
				<div class="wpsdi-notice wpsdi-notice--warn">
					<?php esc_html_e( '⚠ 示例中的 category 仅是示例值。实际使用时必须替换为当前 WordPress 站点「文章 → 分类」页面中已存在的分类名称或分类 ID，或直接删除 category 字段。插件不会自动创建新的分类。', 'wp-structured-draft-importer' ); ?>
				</div>
				<?php $sample = $this->sample_json(); ?>
				<div class="wpsdi-codeblock">
					<button type="button" class="wpsdi-btn wpsdi-btn--ghost wpsdi-copy" data-copy-target="wpsdi-sample"><?php esc_html_e( '复制', 'wp-structured-draft-importer' ); ?></button>
					<pre id="wpsdi-sample" class="wpsdi-pre"><code><?php echo esc_html( $sample ); ?></code></pre>
				</div>

				<h3 class="wpsdi-h3"><?php esc_html_e( '最小可用示例', 'wp-structured-draft-importer' ); ?></h3>
				<div class="wpsdi-notice wpsdi-notice--warn">
					<?php esc_html_e( '⚠ category 字段同样必须使用当前站点已存在的分类名称/ID，或直接省略。', 'wp-structured-draft-importer' ); ?>
				</div>
				<?php $minimal = $this->minimal_json(); ?>
				<div class="wpsdi-codeblock">
					<button type="button" class="wpsdi-btn wpsdi-btn--ghost wpsdi-copy" data-copy-target="wpsdi-minimal"><?php esc_html_e( '复制', 'wp-structured-draft-importer' ); ?></button>
					<pre id="wpsdi-minimal" class="wpsdi-pre"><code><?php echo esc_html( $minimal ); ?></code></pre>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * 渲染 AI 提示词 Tab。
	 *
	 * @return void
	 */
	protected function render_ai_tab() {
		$prompts = $this->ai_prompts();
		?>
		<div class="wpsdi-card">
			<div class="wpsdi-card__head">
				<h2><?php esc_html_e( 'AI 提示词模板', 'wp-structured-draft-importer' ); ?></h2>
				<span class="wpsdi-card__hint"><?php esc_html_e( '直接复制到 千问 / ChatGPT / 豆包 等对话窗口使用。', 'wp-structured-draft-importer' ); ?></span>
			</div>
			<div class="wpsdi-card__body">
				<p class="wpsdi-lead">
					<?php
					echo wp_kses(
						__( '将下方任一提示词粘贴到 AI 对话窗口，并提供你的主题 / 关键词。AI 会按本插件 Schema 输出可直接导入的 JSON。', 'wp-structured-draft-importer' ),
						array( 'strong' => array() )
					);
					?>
				</p>

				<?php foreach ( $prompts as $key => $block ) : ?>
					<div class="wpsdi-prompt">
						<div class="wpsdi-prompt__head">
							<h3 class="wpsdi-h3"><?php echo esc_html( $block['title'] ); ?></h3>
							<div class="wpsdi-prompt__tools">
								<?php foreach ( $block['tags'] as $tag ) : ?>
									<span class="wpsdi-badge wpsdi-badge--muted"><?php echo esc_html( $tag ); ?></span>
								<?php endforeach; ?>
								<button type="button" class="wpsdi-btn wpsdi-btn--ghost wpsdi-copy" data-copy-target="<?php echo esc_attr( $key ); ?>"><?php esc_html_e( '复制', 'wp-structured-draft-importer' ); ?></button>
							</div>
						</div>
						<div class="wpsdi-codeblock">
							<pre id="<?php echo esc_attr( $key ); ?>" class="wpsdi-pre"><code><?php echo esc_html( $block['content'] ); ?></code></pre>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * 占位 JSON。
	 *
	 * @return string
	 */
	protected function placeholder_json() {
		return $this->sample_json();
	}

	/**
	 * 完整示例（Google 收录友好版）。
	 *
	 * @return string
	 */
	protected function sample_json() {
		$sample = array(
			'title'          => '扫地机器人怎么选？2026 主流技术与避坑指南',
			'content'        => '<h2>为什么 2026 年值得入手扫地机器人</h2>' . "\n" . '<p>激光导航、结构光避障与双盘旋转拖地三大技术已下放到 2000 元档，扫地机器人正从「玩具」变为「真生产力」。本文从核心技术、价位段、典型场景三个维度，给出可落地的选购建议。</p>' . "\n" . '<h3>核心技术速览</h3>' . "\n" . '<ul><li>激光导航（LDS）：建图准、不迷路</li><li>结构光避障：识别数据线、拖鞋</li><li>双盘旋转拖地：去除顽固污渍</li></ul>',
			'content_format' => 'html',
			'source_text'    => '（在此粘贴原文，AI 会基于原文改写）',
			'slug'           => 'robot-vacuum-buying-guide-2026',
			'category'       => '智能家居',
			'tags'           => array( '扫地机器人', '智能家居', '选购指南', '激光导航', '避障技术', '拖地机器人', '扫地机推荐' ),
			'excerpt'        => '一文看懂 2026 年扫地机器人主流导航、避障与拖地技术，覆盖小户型、大平层、养宠家庭等典型场景的选购要点，并附 2000-5000 元主流价位推荐与避坑提示，帮你避开营销噱头，买到真正适合自家户型与清洁需求的智能清洁帮手。',
			'yoast_seo'      => array(
				'focus_keyword'    => '扫地机器人',
				'seo_title'        => '2026 扫地机器人选购：主流技术 + 避坑指南',
				'meta_description' => '2026 年扫地机器人怎么选？本文详解激光导航、结构光避障、双盘旋转拖地等核心技术，对比 2000-5000 元主流价位，附场景化选购方案与避坑建议，帮你买到适合自家的智能清洁帮手。',
			),
		);
		return wp_json_encode( $sample, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	}

	/**
	 * 最小示例。
	 *
	 * @return string
	 */
	protected function minimal_json() {
		$minimal = array(
			'title'   => '我的第一篇文章',
			'content' => '<p>正文内容。</p>',
		);
		return wp_json_encode( $minimal, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	}

	/**
	 * AI 提示词模板（Google 收录友好）。
	 *
	 * @return array[]
	 */
	protected function ai_prompts() {
		$schema_block = $this->schema_text_for_prompt();
		$sample      = $this->sample_json();

		$seo_rules          = $this->seo_rules_text();
		$richness_rules     = $this->content_richness_rules_text();

		$common_rules = <<<TEXT
# 角色
你是面向 Google 搜索收录优化的 WordPress 内容创作助手。你的任务：根据用户提供的【主题 / 原文 / 关键词】，输出可直接导入本插件的 JSON 数据。仅输出 JSON 本身，不要任何解释、注释或 Markdown 代码块标记。

# 输出格式（必须严格遵守，否则 JSON 无法解析）
- 必须且只能输出一个 JSON 对象，最外层以 { 开始、以 } 结束。
- 不要使用 ```json 代码块包装，不要附加任何说明文字。
- 字符串使用 UTF-8，中文不要 \u 转义，正斜杠 / 不要转义。
- ★ 关键规则：JSON 字符串值内部的换行符必须写成 \n（两个字符：反斜杠 + n），不能直接在 JSON 里回车。例如 "content" 字段里的 HTML 段落之间要用 \n 分隔。
- ★ 关键规则：JSON 字符串值内部的双引号必须写成 \"，不能直接出现未转义的 "。
- ★ 关键规则：每个键值对后面的逗号不能多写（最后一项后面不要加逗号）。

# Schema 规范（必须严格遵守）
{$schema_block}

{$seo_rules}

{$richness_rules}

# 内容创作规则（改写 + 去 AI 味 + SEO 友好）

## 1. 改写模式（当提供 source_text 时，必须执行「血肉与实体锁定」，防止洗稿失真）
- ★ 绝对禁止过度抽象（去公文腔/去白皮书味）：原文提到的具体产品名、软件名、大模型名字（如 Antigravity, Gemini 3.8 Flash, ChatCut, 剪映, Codex, Claude 等）、真实价格、账号组合技巧（如家庭组多账号轮换）必须 100% 指名道姓保留！严禁将其偷换成“外部 Agent 客户端”“轻量高并发环境”等假大空公文黑话。读者需要具体可落地的方案，不是空泛概括。
- ★ 必须保留原作者的实战血肉与踩坑人情味：原文中原汁原味的实测经历（如替说话卡顿的老板剪口播、逐字对齐心力交瘁）、避坑心得（如为什么严禁拿昂贵的 Codex 剪片、要把珍贵 Token 留给主力开发）、具体实操姿势（如屏幕左边开 Antigravity、右边开 ChatCut 分屏）、进阶玩法（如上传对标爆款成熟视频让 Agent 学习剪辑节奏与花字）必须完整保留并生动呈现，绝不能当作“口语杂质”抹除！
- 原文链接绝对透传：原文中的任何 URL/下载地址（如 https://chatcut.io/zh），必须使用 <a href='URL'>链接文字</a> 内联嵌入正文，严禁吞掉或写成纯文本。
- 升华而非阉割：改写是在原文事实与真实体感之上，理顺逻辑递进、增强排版视觉、补齐对比表格，绝不是把有血有肉的人话洗成干瘪无趣的行业通报。如果未提供 source_text，则基于主题从零创作。

## 2. 去 AI 味（必须遵守）
- 禁止：「首先、其次、最后」「综上所述」「总而言之」「值得注意的是」「不可忽视的是」等机械过渡词。
- 禁止：空洞的排比句、堆砌的形容词、无信息量的修饰语、行业公文八股文腔。
- 禁止：「在当今社会」「随着科技的发展」等陈词滥调开头。
- 必须：用具体事实、真实软件、具体数字、真实踩坑案例支撑观点；用短句、实句、主动语态写作。
- 必须：段落之间靠逻辑自然过渡，不用显性的连接词。
- 必须：像一个真正实操过该工具的行家在与读者面对面深度分享，而不是 AI 在宣读报告。

## 3. title 与 seo_title 必须区分
- title（H1 主标题）：20-40 字，偏文章主标题，可带副标题（如「扫地机器人怎么选？2026 主流技术与避坑指南」）。
- yoast_seo.seo_title（搜索结果标题）：20-40 字，偏搜索结果展示，更凝练（如「2026 扫地机器人选购：主流技术 + 避坑指南」）。
- 两者相似度必须低于 85%，否则插件会警告。

## 4. content 正文（必须纯 HTML，禁止纯文本！）
- ★★★ 最高优先级：content 必须是完整的 HTML，**每一个段落、每一个标题、每一个列表项都必须包裹在 HTML 标签里**。禁止输出纯文本！如果你输出的 content 里没有任何 `<h2>` `<p>` `<ul>` `<table>` 标签，就是错误的，导入后文章会变成一坨无格式的文字。
- ★★★ 禁止用 \\n 换行来"假装分段"。段落必须用 <p>...</p> 包裹，标题必须用 <h2>...</h2>，列表必须用 <ul><li>...</li></ul>，不能用 \\n 代替标签。
- 动态排版与排版元素规范（拒绝固定模板四件套！）：
  · 严禁套用模板：严禁每篇文章都机械塞入“对比表格 + 1234步骤 + 避坑引用块”！排版必须根据文章体裁与内容需求自然规划。
  · <h2>主章节</h2>：3 到 6 个，作为核心章节；可按需使用 <h3> 细化小节。
  · <p>段落文字</p>：所有正文段落必须用 <p> 包裹，严禁纯文本裸奔或用 \n 代替分段。
  · <ul><li> 或 <ol><li>：并列要点/特性清单用 <ul>；仅当存在明确先后次序的操作流程时才用 <ol>。严禁强行把普通叙述拆成 1、2、3、4。
  · <strong>重点加粗</strong>：核心论点、关键数字与结论加粗，禁止整段加粗。
  · <table>：仅当涉及多产品/方案横向指标评测或硬性规格清单时使用；原理解析或观点分析类文章切勿生搬硬套表格。若出现表格，必须是完整的 <table> 结构，严禁压平。
  · <a href='URL'>链接文字</a>：原文/主题中提到的 URL 必须以内联链接形式嵌入正文（属性值用单引号）。
  · <blockquote>引用</blockquote>：仅在引用真实原话、权威表述、设计权衡代价或关键风险提示时使用；严禁千篇一律冠以“资深技术博主实测避坑”套路。
  · <code>：涉及技术命令、配置参数、文件扩展名、代码片段时使用 <code> 包裹。
- 禁止 Markdown 语法：不要用 ## 标题、不要用 [text][1] 引用式链接、不要用 [1]: 脚注、不要用 | 表格 |、不要用 **加粗**。
- 正文字数不少于 1200 字，段落长短参差，信息密度充实。
- 首段 80-120 字内自然出现焦点关键词 1 次。
- ★ 关键规则：HTML 标签里的属性值必须用**单引号**，不要用双引号。正确：<a href='https://...'>文字</a>；错误：<a href="https://...">文字</a>（双引号会破坏 JSON 字符串）。URL 也不要用反引号 ` 包裹。
- 写 JSON 时，HTML 换行用 \n 转义，双引号用 \" 转义。
- 具体结构、表格使用判断、主动搜索扩充等规则见上方「内容丰富度与可读性规则」一节，必须严格遵守。

## 5. excerpt 与 meta_description 必须区分
- excerpt（列表页摘要）：80-160 字，偏文章概要，与 meta_description 不重复。
- yoast_seo.meta_description（搜索结果描述）：130-160 字，偏吸引点击，自然包含焦点关键词。
- 两者相似度必须低于 85%。

## 6. 其他字段
- category：**必须是当前 WordPress 站点已有的分类名称（中文名称字符串）或分类 ID（整数）**。插件不会自动创建新分类。不确定分类名时直接省略该字段，草稿创建后再到 WordPress 后台手动选择。分类名称必须与后台「文章 → 分类」中显示的名称完全一致（例如后台是「智能家居」就写「智能家居」，不能写「智能家俱」）。
- tags：6-10 个简短中文短语（2-6 字），常见可检索表达。不存在的标签 WordPress 会自动创建。
- slug：kebab-case 全小写英文，2-5 词。

# ★★★ 输出前自检（必须执行，否则导入失败）
在输出 JSON 前，必须逐条检查：
1. content 字段里是否包含 <h2>、<p> 标签？如果没有，**立即重写**——不要输出纯文本！
2. content 字段里是否有至少 3 个 <h2>？如果没有，补充标题。
3. content 字段里是否有对比/规格类内容但没有用 <table>？如果有，改成 <table>。
4. content 字段里是否有列表内容但没有用 <ul><li>？如果有，改成列表。
5. 原文/主题中提到的 URL 是否以 <a href='URL'> 形式出现在 content 里？如果没有，加上。
6. JSON 字符串值内部的换行是否用了 \n 转义？双引号是否用了 \" 转义？
7. HTML 标签属性值是否用了单引号（不是双引号）？
**如果以上任何一条不满足，不要输出，先修正再输出。**

# 参考示例
{$sample}

# 用户输入
主题 / 原文 / 关键词：
{{在此填写用户主题}}
TEXT;

		return array(
			'wpsdi-prompt-full'    => array(
				'title'   => __( '通用完整提示词（推荐，Google 收录优化）', 'wp-structured-draft-importer' ),
				'tags'    => array( '千问', 'ChatGPT', '豆包' ),
				'content' => $common_rules,
			),
			'wpsdi-prompt-short'   => array(
				'title'   => __( '极简提示词（高速产出）', 'wp-structured-draft-importer' ),
				'tags'    => array( '快速', '精简' ),
				'content' => <<<TEXT
你是面向 Google 收录优化的 WordPress 内容助手。仅输出一个 JSON 对象，不要任何解释或代码块标记。中文不要 \u 转义，/ 不要转义。

★ JSON 格式硬性规则：
- 字符串内换行必须用 \n 转义（如 content 字段里的 HTML），不能直接回车。
- 字符串内双引号必须用 \" 转义。
- 末尾不要多写逗号。

★ 内容规则：
- 改写模式：绝对保留具体软件名、模型名、真实数字、链接、操作姿势与实操踩坑故事，严禁过度抽象成假大空公文词；基于原文深度升华，不是机械复述。
- 去 AI 味：禁止「首先其次」「综上所述」等机械过渡词与行业公文腔；用真实工具、实测避坑与案例支撑。
- title（H1）与 seo_title（搜索结果）必须区分，相似度<85%。
- ★★★ content 必须纯 HTML：每个段落用 <p>，标题用 <h2>，列表用 <ul><li>，对比用 <table>（严禁把表格压平成一行纯文本！），加粗用 <strong>，链接用 <a href='URL'>。禁止纯文本！禁止用 \n 假装分段！原文中的 URL 必须以 <a href='URL'> 出现在正文里。
- content ≥3 个 h2，禁止 Markdown 脚注/引用/链接/表格语法。
- ★ HTML 属性值用单引号：<a href='https://...'>，不要用双引号（会破坏 JSON）。URL 不要用反引号 ` 包裹。
- excerpt 与 meta_description 必须区分，相似度<85%。
- 结构丰富度：≥3 个 h2 + h3 子标题，禁止"开头-三段-总结"固定三段式；段落长短参差。
- 表格判断：对比/规格/价格类内容必须用 <table>（结构完整，绝不可输出纯文本假表格）；简单列表用 <ul>。
- 主动搜索：如带联网能力，先搜最新数据/官方定价/真实链接，写进正文（用 <a href='URL'>文字</a> 内联链接），不要编造。
- 字数 ≥1200 字，信息密度高。

Schema：
{$schema_block}

{$seo_rules}

{$richness_rules}

示例：
{$sample}

用户主题/原文：{{在此填写}}
TEXT,
			),
			'wpsdi-prompt-system'  => array(
				'title'   => __( 'System Prompt（用于 API / 自定义 GPT）', 'wp-structured-draft-importer' ),
				'tags'    => array( 'System', 'API', 'Custom GPT' ),
				'content' => <<<TEXT
你是面向 Google 搜索收录优化的 WordPress 草稿生成器。当用户发送主题或原文时，必须输出符合下方 Schema 的 JSON 对象，且仅输出 JSON 本身。

禁止：解释、Markdown 代码块标记（```）、前后空白以外的文本、注释、多 JSON。
强制：UTF-8 中文不转义，正斜杠 / 不转义，最外层是单一 {}。

★ JSON 格式硬性规则：
- 字符串内换行必须用 \n 转义（如 content 字段里的 HTML），不能直接在 JSON 字符串里回车。
- 字符串内双引号必须用 \" 转义，不能直接出现未转义的 "。
- ★ HTML 标签属性值必须用单引号：<a href='https://...'>，不要用双引号（双引号会破坏 JSON 字符串）。URL 不要用反引号 ` 包裹。
- 末尾不要多写逗号。

★ 内容创作规则：
1. 改写模式：当用户提供 source_text 时，必须锁定具体实体（保留具体产品名、模型名、价格、链接、避坑经验、操作细节），严禁抽象成公文套话；在原文事实与真实体感之上丰富重写。
2. 去 AI 味：禁止「首先/其次/最后」「综上所述」「值得注意的是」等机械过渡词；禁止假大空公文腔与空洞排比；像真正实操过该工具的行家在深度分享。
3. title（H1 主标题，20-40 字）与 seo_title（搜索结果标题，20-40 字）必须区分，相似度<85%。
4. content 必须纯 HTML（h2/h3/p/ul/li/a/strong/blockquote/table），≥1200 字；禁止 Markdown 脚注[1]、引用链接[text][1]、| 表格 |、**加粗**。
   ★★★ 最高优先级：每个段落必须用 <p> 包裹，标题用 <h2>，列表用 <ul><li>，对比用 <table>（严禁把表格压平成一行文本！）。禁止纯文本输出！禁止用 \n 假装分段！原文/主题中的 URL 必须以 <a href='URL'> 内联出现在正文里。
5. 结构丰富度：≥3 个 h2 + 视情况用 h3；段落长短参差；禁止"开头-三段-总结"固定三段式；对比/规格/价格必须用 <table>，简单列表用 <ul>。
6. 主动搜索扩充：如带联网能力，先搜最新数据/官方定价/真实链接，把事实写进正文，用 <a href='URL'>文字</a> 内联引用；无联网时用知识库可信事实，不要编造数字和日期。
7. excerpt（列表页摘要，80-160 字）与 meta_description（搜索结果描述，130-160 字）必须区分，相似度<85%。
8. SEO 规则见下方。

完整内容丰富度规则：
{$richness_rules}

Schema：
{$schema_block}

{$seo_rules}

参考示例：
{$sample}

收到主题/原文后，仅输出一个 JSON 对象。
TEXT,
			),
		);
	}

	/**
	 * 内容丰富度规则（结构化 / 反三段式 / 主动搜索扩充 / 表格判断）。
	 *
	 * @return string
	 */
	protected function content_richness_rules_text() {
		return <<<TEXT
# 内容丰富度与可读性规则（必须严格遵守，否则文章会很"AI"）

## 0. HTML 标签强制使用（最高优先级，违反则文章无格式）
- content 字段里的所有内容必须用 HTML 标签包裹，禁止裸文本。
- 段落 → <p>...</p>；标题 → <h2>...</h2> 或 <h3>...</h3>；列表 → <ul><li>...</li></ul>；加粗 → <strong>...</strong>；引用 → <blockquote>...</blockquote>；链接 → <a href='URL'>...</a>。
- 禁止用 \n 换行来代替标签。两个段落之间可以是 \n（JSON 转义换行），但每个段落本身必须用 <p> 包裹。
- 对比/规格/价格类内容必须用 <table><thead><tr><th>...</th></tr></thead><tbody><tr><td>...</td></tr></tbody></table>，禁止用 \n 纯文本排列假装表格。

## 1. 多级标题结构（强制）
- 正文必须使用 h2 划分主要章节，至少 3 个 h2；复杂主题再用 h3 做二级划分。
- 标题不要写成"概述""详细说明""总结"这种空泛词；要带具体信息量，如「Gemini 3.5 Transcribe 的定价与错率」「本地 Whisper 在 2026 MBP M3 上的实测耗时」。
- 标题之间逻辑递进：背景 → 关键事实/数据 → 对比/拆解 → 场景/选型 → 收束。不要套固定模板。
- 全文 h2/h3 总数不少于 4 个，每个 h2 下至少 1-3 段 p，或搭配 ul/ol/table。

## 2. 反"固定三段式"（强制）
- 禁止"开头总览 → 三段并列 → 总结"这种千篇一律的 AI 味结构。
- 每篇文章的结构要根据主题本身选择：可以是「事件时间线」「产品对比」「问题→方案→实测」「观点交锋」「深度拆解一个点」「列表式盘点」等。
- 同一会话内连续产出多篇文章时，必须切换不同结构模式，不能连续两篇都用"先讲背景、再分三点、最后总结"。
- 段落长度要参差：有 2-3 句的短段落用来强调，也有 5-8 句的长段落用来深入；不要每段都是 4-5 句的均匀块。

## 3. 主动搜索与内容扩充（强烈建议）
- 如果你的运行环境带联网搜索能力（如 ChatGPT Browse、Grok Search、千问联网、豆包搜索），在动笔前先搜索以下任一项：
  · 主题相关的最新数据、官方定价、版本号、发布日期；
  · 主题中提到的产品/事件的真实链接（官网、changelog、官方文档）；
  · 主题相关的对比项（竞品规格、行业基线数据）。
- 把搜索到的事实写进正文：具体数字（价格、错率、时长、版本）、具体日期、具体产品名。
- 原文/主题中如果提到某个链接或产品名，要主动去理解这个链接指向什么、补充它的背景；不要简单复述"某产品发布了某功能"。
- 如果当前模型无联网能力，则用你知识库里最近的可信事实；不要编造数字和日期。
- 在正文里引用来源时，用 <a href='真实URL'>文字</a> 的内联链接形式（属性值用单引号），不要用 Markdown 脚注或引用式链接，也不要用双引号包属性值。

## 4. 表格使用判断（因需而设，严禁强塞，严禁压平）
- ★ 表格绝非每篇文章的必选元素！仅在存在真实、硬核的「多产品/多方案横向参数对比」、「价格/套餐多维对比」、「硬件或配置规格清单」时才使用 <table>。
- 分析性文章、架构原理剖析、行业动态评论、方法论探讨类文章，坚决不要无中生有硬编对比表格！强塞空洞表格只会显得机器味十足。
- 一旦需要使用表格，必须输出完整闭合的 HTML 结构：<table><thead><tr><th>...</th></tr></thead><tbody><tr><td>...</td></tr>...</tbody></table>。
- ★ 极重要禁令：绝对严禁把多列对比内容压平成一行纯文本（如严禁输出“对比维度方案A方案B成本免费...”）；也不要用 table 装饰简单单列数据（3 个以下单项要点直接用 <ul><li>）。

## 5. 视觉节奏与元素自然呼吸（杜绝套路四件套）
- 严禁每篇文章都机械遵循“先画表 ➔ 再写1234步骤 ➔ 再来个避坑引用块”的僵化套路！
- 列表分类：仅当存在前后次序的排查/操作指南时才用 <ol>；并列的核心特性、亮点、注意事项用 <ul>。严禁为了凑格式把普通观点强拆成 1、2、3、4。
- 引用块 <blockquote>：仅在引用真实原话、设计权衡代价、官方政策或关键警示时使用。避免千篇一律冠以“资深技术博主实测避坑”这种模板化标题。
- 关键论点、关键数字、关键结论用 <strong> 加粗，但不要整段加粗。
- 技术名词、终端指令、配置键名、扩展名用 <code> 包裹。

## 6. 字数与密度
- 全文不少于 1200 字（原 800 字下限已提高）。
- 信息密度高：每段都要有具体信息（事实/数据/案例/观点），不要写"这件事很重要""值得关注"这种空话。
- 宁可写一个具体的小切片深挖，也不要写一个大而全但每个点都浮在表面的"综述"。

TEXT;
	}

	/**
	 * SEO 规则文本（Google 收录友好 5 项）。
	 *
	 * @return string
	 */
	protected function seo_rules_text() {
		return <<<TEXT
# Google 收录友好 SEO 规则（必须严格遵守）
1. yoast_seo.seo_title（SEO 标题 / Title Tag）
   - 长度：20-40 个汉字。
   - 必须含焦点关键词并尽量靠前放置；可使用 ｜ 或 - 分隔附加词。
   - Google 中文搜索结果标题展示宽度有限：过短不够吸引、过长被截断。
   - 不要与文章 title 完全一致（seo_title 偏搜索结果，title 偏 H1）。

2. yoast_seo.meta_description（元描述 / Meta Description）
   - 长度：130-160 个汉字（务必控制在此区间，过短信息量不足，过长被 Google 截断）。
   - 焦点关键词自然出现 1-2 次，不要堆砌。
   - 用通顺完整的句子，吸引点击，避免与 seo_title 完全一致。

3. yoast_seo.focus_keyword（核心 SEO 关键词）
   - 2-6 个汉字的短词或短语。
   - 必须是用户在 Google 实际会搜索的词，简短、清晰、可检索。
   - 不能写成一句话或一个完整标题；不要包含标点。
   - 只输出 1 个最核心的关键词。

4. tags（SEO 标签）
   - 6-10 个简短中文短语，每个 2-6 字。
   - 必须是常见、可检索的表达，适合站内「标签 / 话题」使用。
   - 不要 #、不要 emoji、不要长句、不要重复。
   - 以数组形式输出。

5. slug（固定链接 Permalink）
   - 全小写英文 + 连字符（kebab-case），2-5 个英文单词。
   - 贴近文章主题，简短、有含义，便于 Google 索引与用户记忆。
   - 不含中文、空格、特殊符号、连字符开头或结尾。
   - 只输出 1 条最优 slug（不要提供多个建议）。
TEXT;
	}

	/**
	 * 为 AI 提示词生成简洁 Schema 文本（Google 收录友好版）。
	 *
	 * @return string
	 */
	protected function schema_text_for_prompt() {
		return <<<TEXT
{
  "title":          "string, 必填, 20-40 个汉字含焦点关键词, H1 主标题",
  "content":        "string, 必填, ★必须纯 HTML 禁止纯文本！≥1200 字, ≥3 个 h2, 每段用 <p> 包裹, 对比用 <table>, 列表用 <ul><li>, 加粗用 <strong>, 链接用 <a href='URL'>, 禁止 Markdown 脚注/引用/表格",
  "content_format": "'html' 或 'markdown'，默认 'html'",
  "source_text":    "string, 可选, 原文（用于改写模式）",
  "slug":           "string, 可选, kebab-case 全小写英文+连字符, 2-5 词, ≤60 字符",
  "category":       "string(WP已存在的分类中文名称) | integer(分类ID)，可选。只能用当前站点已有分类，插件不会自动创建新分类；如不确定可省略，草稿建立后在后台手动选择",
  "tags":           ["string", ...], 可选, 6-10 个简短中文短语",
  "excerpt":         "string, 可选, 80-160 字含焦点关键词, 与 meta_description 不重复",
  "yoast_seo": {
    "focus_keyword":    "string, 2-6 个汉字, 用户实际搜索词, 仅 1 个",
    "seo_title":        "string, 20-40 个汉字含焦点关键词靠前, 与 title 区分",
    "meta_description": "string, 130-160 个汉字含焦点关键词 1-2 次, 与 excerpt 不重复"
  }
}
TEXT;
	}

	/**
	 * 处理 admin-post 导入请求（无 JS 也可用）。
	 *
	 * @return void
	 */
	public function handle_import_post() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( '权限不足。', 'wp-structured-draft-importer' ) );
		}

		check_admin_referer( self::NONCE_ACTION, 'wpsdi_nonce' );

		// WordPress wp_magic_quotes() 对 $_POST 自动 addslashes，所以这里先用 wp_unslash
		// 还原；具体的 JSON 内容转义修复在 importer->parse() 内部继续处理。
		$json = isset( $_POST['wpsdi_json'] ) ? (string) wp_unslash( $_POST['wpsdi_json'] ) : '';
		$json = trim( $json );
		$json = preg_replace( '/^\xEF\xBB\xBF/', '', $json );

		// 保存最近输入（截断防止超长）。
		update_user_meta( get_current_user_id(), self::OPTION_LAST_JSON, mb_substr( $json, 0, 65535 ) );

		$importer = new WPSDI_Importer();
		$importer->parse( $json );
		$result = $importer->import();

		$flash = array(
			'type'     => $result['success'] ? 'success' : 'error',
			'title'    => $result['success'] ? __( '草稿创建成功', 'wp-structured-draft-importer' ) : __( '导入失败', 'wp-structured-draft-importer' ),
			'messages' => array(),
		);

		if ( $result['success'] ) {
			$flash['messages'][] = sprintf(
				/* translators: %d: 文章 ID。 */
				__( '草稿 ID：%d', 'wp-structured-draft-importer' ),
				(int) $result['post_id']
			);
			if ( ! empty( $result['warnings'] ) ) {
				$flash['messages'] = array_merge( $flash['messages'], $result['warnings'] );
			}
			$flash['edit_url'] = $result['edit_url'];
		} else {
			$flash['messages'] = ! empty( $result['errors'] ) ? $result['errors'] : array( __( '未知错误。', 'wp-structured-draft-importer' ) );
		}

		set_transient( 'wpsdi_flash_' . get_current_user_id(), $flash, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
		exit;
	}

	/**
	 * AJAX：解析预览。
	 *
	 * @return void
	 */
	public function ajax_preview() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'wp-structured-draft-importer' ) ), 403 );
		}

		// WordPress wp_magic_quotes() 对 $_POST 自动 addslashes，先还原；
		// 具体的 JSON 内容转义修复在 importer->parse() 内部继续处理。
		$json = isset( $_POST['json'] ) ? (string) wp_unslash( $_POST['json'] ) : '';

		$importer = new WPSDI_Importer();
		$importer->parse( $json );

		// 即使存在校验错误，也返回已解析数据用于预览，同时附带错误列表和警告列表。
		wp_send_json_success(
			array(
				'data'     => $importer->get_data(),
				'errors'   => $importer->get_errors(),
				'warnings' => $importer->get_warnings(),
			)
		);
	}

	/**
	 * 取出并删除 flash 临时数据。
	 *
	 * @return array|null
	 */
	protected function take_flash() {
		$key  = 'wpsdi_flash_' . get_current_user_id();
		$data = get_transient( $key );
		if ( $data ) {
			delete_transient( $key );
		}
		return $data ? $data : null;
	}
}
